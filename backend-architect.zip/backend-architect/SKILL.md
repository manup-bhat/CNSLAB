---
name: backend-architect
description: |
  End-to-end backend engineering skill that designs, builds, hardens, and verifies
  production-ready backends on ANY tech stack, for BOTH new (greenfield) and existing
  (brownfield) applications. Use when: designing a new backend or service from scratch,
  choosing an architecture (monolith vs microservices vs event-driven vs serverless),
  doing high-level design (HLD) or low-level design (LLD), modeling data and choosing
  SQL vs NoSQL, designing REST/GraphQL/gRPC APIs, adding real-time features (WebSockets,
  SSE, webhooks), designing pub/sub and message-queue/event-streaming pipelines, adding
  caching, scaling a system and planning for load, securing an API, making a service
  production-ready (observability, resilience, 12-Factor, CI/CD), writing testing
  strategy, or finding a backend bug, tracing its root cause, and fixing it safely.
  Works for any language/framework: Node.js (Express/NestJS), Python (FastAPI/Django/
  Flask), Java (Spring Boot), .NET (ASP.NET Core), Go (Gin/Echo), Ruby (Rails),
  PHP (Laravel), Rust (Axum/Actix), and more.
  Trigger on: "design a backend", "backend architecture", "how should I architect this",
  "monolith vs microservices", "modular monolith", "event-driven architecture",
  "serverless backend", "high level design", "HLD", "low level design", "LLD",
  "system design", "design the API", "REST API design", "REST vs GraphQL vs gRPC",
  "API versioning", "pagination", "idempotency", "rate limiting", "websockets",
  "server-sent events", "real-time backend", "pub/sub", "message queue", "Kafka",
  "RabbitMQ", "event streaming", "saga pattern", "CQRS", "event sourcing",
  "outbox pattern", "API gateway", "service discovery", "circuit breaker",
  "database design", "SQL or NoSQL", "schema design", "indexing", "sharding",
  "replication", "database per service", "caching strategy", "cache invalidation",
  "Redis", "scale my backend", "horizontal scaling", "load balancing", "CAP theorem",
  "connection pooling", "N+1 query", "secure my API", "OWASP API top 10", "authentication",
  "authorization", "JWT", "OAuth2", "RBAC", "production ready", "12-factor",
  "observability", "logging metrics tracing", "health checks", "graceful shutdown",
  "resilience", "retries and timeouts", "testing strategy", "load testing",
  "contract testing", "find the bug", "root cause", "why is this failing",
  "debug the backend", "fix this issue", "build a microservice", "build a service",
  "DDD", "domain driven design", "clean architecture", "hexagonal architecture",
  "how do I do this in Node/FastAPI/Spring/.NET/Go", "backend best practices",
  "make this production grade", "plan a new app", "migrate a monolith",
  "which tech stack", "what backend stack should I use", "choose a tech stack",
  "compare backend frameworks", "best framework for", "detect the tech stack",
  "identify the framework", "work with an existing stack", "existing codebase stack",
  "what stack is this", "any tech stack", "Elixir", "Phoenix", "Kotlin", "Ktor",
  "Bun", "Deno", "Quarkus", "Micronaut".
argument-hint: 'Optional scope: "design new backend", "choose architecture", "design API", "database design", "add caching", "scale this", "secure API", "make production ready", "find a bug", "build in <stack>", or a component/module path'
---

# Backend Architect Skill

> "Everything is a trade-off. There is no single correct architecture — only the one that
> best fits *this* system's requirements, scale, team, and phase." — adapted from the
> System Design community

> "First make it correct, then make it clear, then make it fast — and never skip observability."

A complete operating system for backend engineering. This skill takes any backend task —
from a blank page to a broken production service — and drives it through a disciplined loop:
**FRAME → MODEL → DESIGN → BUILD → HARDEN → PROVE**. It is **tech-stack agnostic**: the
principles are universal, and [tech-stack-guide.md](./references/tech-stack-guide.md) maps every
concept to idiomatic code in Node.js, Python, Java/Spring, .NET, Go, Ruby, PHP, and Rust.

**What makes this comprehensive**: it covers requirements & capacity estimation, data modeling
& databases (SQL/NoSQL), high-level architecture (HLD), low-level design (LLD/DDD/SOLID),
API design (REST/GraphQL/gRPC), real-time & messaging (WebSockets/pub-sub/queues/streaming),
caching, scaling & performance, security (OWASP API + Web Top 10), production-readiness
(observability/resilience/12-Factor), testing strategy, and systematic bug detection with
root-cause fixing — for both new builds and existing systems.

---

## 🧠 The Backend Reasoning OS — Read This First

**This is what makes any model — large or small — engineer like a principal backend engineer.**
Weak solutions jump straight to code, ignore non-functional requirements, and bolt on security
and observability last. Run every backend task through the **FRAME · MODEL · DESIGN · BUILD ·
HARDEN · PROVE** loop:

```
 FRAME ─→ MODEL ─→ DESIGN ─→ BUILD ─→ HARDEN ─→ PROVE
  reqs     domain   HLD +     write     secure,   test,
  scale,   & data   LLD,      idiomatic scale,    find root
  SLOs,    model,   arch      production cache,    cause,
  limits   API      style &   -ready     observe,  fix safely,
 (ground   contract patterns  code       resilient ship-gate
  truth)
```

**Prime directive**: *No design decision without a requirement behind it; no recommendation
without a stated trade-off; no "production-ready" claim without security, observability, and
tests.* At every step, **calibrate to scale and phase** — the right answer for a 100-user MVP
is wrong for a 100M-user platform, and vice-versa. Over-engineering is as harmful as
under-engineering.

> **Full protocol** (requirements traceability, scale calibration, greenfield vs brownfield
> gates, assumption logging, confidence calibration, stopping conditions): see
> [reasoning-protocol.md](./references/reasoning-protocol.md). **Read it first.**

---

## How The Phases Relate

```
backend-architect
├── FRAME  — Capture requirements, constraints, scale, SLOs; estimate capacity
│       └── → reference: requirements-and-estimation.md
├── MODEL  — Model the domain and data; choose SQL/NoSQL; define contracts
│       └── → reference: data-modeling-and-databases.md
├── DESIGN — High-level architecture + low-level component/class design
│       ├── → reference: architecture-styles.md          (HLD: pick the style)
│       ├── → reference: microservices-and-distributed.md (HLD: distributed patterns)
│       └── → reference: low-level-design.md              (LLD: DDD/SOLID/patterns)
├── (COMMS as part of DESIGN/BUILD) — API + real-time/eventing surfaces
│       ├── → reference: api-design.md                    (REST/GraphQL/gRPC)
│       └── → reference: realtime-and-messaging.md        (WS/SSE/pub-sub/queues/streaming)
├── BUILD  — Implement production-ready code, tech-stack agnostic
│       ├── → reference: implementation-playbook.md       (end-to-end recipe)
│       └── → reference: tech-stack-guide.md              (idiomatic per-stack snippets)
├── HARDEN — Make it secure, fast, scalable, resilient, observable
│       ├── → reference: caching.md
│       ├── → reference: scaling-and-performance.md
│       ├── → reference: security.md
│       └── → reference: production-readiness.md
└── PROVE  — Test it, find bugs, trace root cause, fix safely, gate the release
        ├── → reference: testing-strategy.md
        ├── → reference: bug-detection-and-fixing.md
        └── → reference: checklist.md                     (consolidated ship gates)
```

---

## Quick Reference

| Phase | Reference File | Purpose |
|-------|---------------|---------|
| ★ — Reasoning OS | [reasoning-protocol.md](./references/reasoning-protocol.md) | How to engineer at principal level on any model (read first) |
| FRAME | [requirements-and-estimation.md](./references/requirements-and-estimation.md) | Functional/non-functional reqs, SLA/SLO/SLI, capacity estimation |
| MODEL | [data-modeling-and-databases.md](./references/data-modeling-and-databases.md) | SQL vs NoSQL, schema, indexing, transactions, sharding/replication |
| DESIGN (HLD) | [architecture-styles.md](./references/architecture-styles.md) | Monolith/microservices/event-driven/serverless; decision matrix |
| DESIGN (HLD) | [microservices-and-distributed.md](./references/microservices-and-distributed.md) | Decomposition, Saga, CQRS, event sourcing, gateway, discovery |
| DESIGN (LLD) | [low-level-design.md](./references/low-level-design.md) | DDD, SOLID, design patterns, clean/hexagonal layering, concurrency |
| COMMS | [api-design.md](./references/api-design.md) | REST/GraphQL/gRPC, versioning, pagination, idempotency, errors |
| COMMS | [realtime-and-messaging.md](./references/realtime-and-messaging.md) | WebSockets, SSE, pub/sub, queues, Kafka, delivery semantics |
| BUILD | [implementation-playbook.md](./references/implementation-playbook.md) | End-to-end recipe to build/extend a production service |
| BUILD | [tech-stack-guide.md](./references/tech-stack-guide.md) | Stack selection + decision framework, detecting an existing stack, idiomatic snippets (Node, Python, Java, .NET, Go, Ruby, PHP, Rust, Elixir, Kotlin) |
| HARDEN | [caching.md](./references/caching.md) | Cache layers, strategies, invalidation, Redis patterns |
| HARDEN | [scaling-and-performance.md](./references/scaling-and-performance.md) | Scaling, load balancing, CAP, DB scaling, rate limiting, N+1 |
| HARDEN | [security.md](./references/security.md) | OWASP API + Web Top 10, authn/authz, injection, secrets |
| HARDEN | [production-readiness.md](./references/production-readiness.md) | 12-Factor, observability, resilience, health checks, CI/CD |
| PROVE | [testing-strategy.md](./references/testing-strategy.md) | Test pyramid, contract/load testing, testcontainers |
| PROVE | [bug-detection-and-fixing.md](./references/bug-detection-and-fixing.md) | Bug classes, 5-Whys root cause, reproduction, fix + regression |
| GATE | [checklist.md](./references/checklist.md) | Requirements/design/API/security/scaling/pre-ship checklists |

---

## ⚡ Copilot Smart Routing — Read Only What's Needed

**CRITICAL**: Do NOT read all 17 reference files for every request. Match the user's intent to
the right subset. For focused questions read 1–3 files; for a full greenfield design read the
FRAME→DESIGN chain; for "make production ready" read the HARDEN + PROVE files.

| User Intent / Task | Phases | Reference Files to Read |
|--------------------|--------|-------------------------|
| **"Design a whole new backend" / "architect this app"** | All | reasoning-protocol → requirements-and-estimation → data-modeling-and-databases → architecture-styles → (microservices-and-distributed) → low-level-design → api-design → checklist |
| **"How should I reason about this" / methodology** | ★ | reasoning-protocol |
| **"Gather requirements" / "estimate capacity/QPS/storage"** | FRAME | requirements-and-estimation |
| **"Design the database" / "SQL or NoSQL" / "schema" / "indexing" / "sharding"** | MODEL | data-modeling-and-databases |
| **"Which architecture" / "monolith vs microservices" / "serverless" / "event-driven"** | HLD | architecture-styles |
| **"Microservices patterns" / "saga" / "CQRS" / "event sourcing" / "API gateway"** | HLD | microservices-and-distributed |
| **"LLD" / "class design" / "DDD" / "design patterns" / "clean architecture"** | LLD | low-level-design |
| **"Design an API" / "REST vs GraphQL vs gRPC" / "versioning" / "pagination"** | COMMS | api-design |
| **"WebSockets" / "real-time" / "pub-sub" / "queue" / "Kafka" / "events"** | COMMS | realtime-and-messaging |
| **"Build/implement a service/feature"** | BUILD | implementation-playbook + tech-stack-guide |
| **"Which tech stack / choose a stack / compare frameworks / best framework for X"** | BUILD | tech-stack-guide (Selection Cheat-Sheet + Decision Framework) |
| **"What stack is this / detect / work with the existing stack" (brownfield)** | BUILD | tech-stack-guide (Detecting & Working With an Existing Stack) |
| **"How do I do X in Node/FastAPI/Spring/.NET/Go/Rails/Laravel/Rust/Elixir/Kotlin"** | BUILD | tech-stack-guide (+ the topic file) |
| **"Add caching" / "cache invalidation" / "Redis"** | HARDEN | caching |
| **"Scale this" / "load balancing" / "performance" / "N+1" / "rate limiting"** | HARDEN | scaling-and-performance |
| **"Secure my API" / "OWASP" / "auth" / "JWT/OAuth2" / "injection"** | HARDEN | security |
| **"Production ready" / "observability" / "12-factor" / "resilience" / "deploy"** | HARDEN | production-readiness |
| **"Testing strategy" / "load test" / "contract test"** | PROVE | testing-strategy |
| **"Find the bug" / "root cause" / "why failing" / "debug" / "fix"** | PROVE | bug-detection-and-fixing |
| **"Ready to ship?" / "review checklist"** | GATE | checklist |
| **"Make this existing backend better" (brownfield)** | FRAME→HARDEN | requirements-and-estimation (discovery) → scaling-and-performance → security → production-readiness → bug-detection-and-fixing |

**Rule**: For targeted queries, read 1–3 files. For full designs, read the phase chain. Always
apply the reasoning protocol's *requirement-first, trade-off-explicit, scale-calibrated* discipline.

---

## Copilot Execution Strategy

Choose the path based on whether the backend is new or existing.

### Path A — Greenfield (new backend / service / feature)
```
1. FRAME   Clarify functional + non-functional requirements. Estimate scale (QPS, data,
           latency budget, read/write ratio). Record assumptions. → requirements-and-estimation
2. MODEL   Model the domain (entities, aggregates, bounded contexts). Choose data store(s).
           Define API/event contracts. → data-modeling-and-databases
3. DESIGN  Pick an architecture style justified by the requirements (default: modular monolith
           unless scale/org forces microservices). Do LLD for the core modules.
           → architecture-styles, microservices-and-distributed, low-level-design
4. COMMS   Design the API and any real-time/eventing surfaces. → api-design, realtime-and-messaging
5. BUILD   Implement with clean layering, validation, error handling, config, logging.
           → implementation-playbook, tech-stack-guide
6. HARDEN  Add security, caching, scaling headroom, resilience, observability.
           → security, caching, scaling-and-performance, production-readiness
7. PROVE   Write the test pyramid; run the ship checklist. → testing-strategy, checklist
```

### Path B — Brownfield (existing backend to improve / scale / fix)
```
1. FRAME   Discover ground truth first: map endpoints, data flows, dependencies, current
           SLOs, pain points, incident history. Do NOT change code before you understand it.
2. LOCATE  Identify the specific concern (bug, bottleneck, vulnerability, tech-debt).
3. ROUTE   Jump to the matching HARDEN/PROVE file (security / scaling-and-performance /
           production-readiness / bug-detection-and-fixing).
4. ROOT    For bugs, trace to root cause (5-Whys, blast radius) before patching.
5. VERIFY  Add a regression test that fails before the fix and passes after. Re-run checklist.
```

### Tooling first (both paths)
```bash
# Objective ground truth before manual analysis
# Dependencies & CVEs
npm audit 2>/dev/null || pip-audit 2>/dev/null || mvn dependency-check:check 2>/dev/null || \
  dotnet list package --vulnerable 2>/dev/null || govulncheck ./... 2>/dev/null
# Endpoint / route inventory (adapt per stack)
grep -rEn "@(Get|Post|Put|Delete|Patch)Mapping|app\.(get|post|put|delete|patch)|@router\.(get|post)|MapGet|MapPost|http\.HandleFunc" .
# Slow query / N+1 hints
grep -rEn "SELECT .* FROM|\.find\(|\.query\(|\.all\(\)" . | head -50
# Test coverage
npm test -- --coverage 2>/dev/null || pytest --cov 2>/dev/null || go test ./... -cover 2>/dev/null
```

---

## Phase 1 — FRAME (Requirements & Estimation)

**Goal**: Establish ground truth before designing anything. A design without requirements is a
guess. Capture **functional requirements** (what it must do) and **non-functional requirements**
(scale, latency, availability, consistency, security, cost) — the NFRs drive the architecture.

Key outputs:
- Functional list + primary use cases and workflows.
- NFRs with **numbers**: target QPS (peak & average), data volume/growth, p50/p95/p99 latency
  budgets, availability target (how many 9s), read:write ratio, consistency needs.
- Back-of-envelope capacity estimate (traffic, storage, bandwidth, memory).
- Explicit **assumptions** and **constraints** (team size, deadline, existing systems, budget).

> **Full guide** (NFR catalog, SLA/SLO/SLI, estimation formulas, brownfield discovery):
> see [requirements-and-estimation.md](./references/requirements-and-estimation.md)

---

## Phase 2 — MODEL (Domain, Data & Contracts)

**Goal**: Model the domain and choose how data is stored and accessed. Most backend complexity
is data complexity; get this right early because it is the hardest thing to change later.

Key decisions:
- Domain entities, relationships, aggregates, bounded contexts (DDD tactical modeling).
- **SQL vs NoSQL** per data set, driven by access patterns — not fashion.
- Schema design, normalization vs denormalization, indexing strategy.
- Transaction/consistency requirements (ACID vs BASE, isolation levels).
- API and event **contracts** (the stable interface others depend on).

> **Full guide** (SQL/NoSQL decision matrix, indexing, ACID/isolation, sharding, replication,
> NoSQL types, migrations, per-DB best practices): see
> [data-modeling-and-databases.md](./references/data-modeling-and-databases.md)

---

## Phase 3 — DESIGN (HLD + LLD)

**Goal**: Decide the shape of the system (HLD) and the shape of the code (LLD).

**High-Level Design (HLD)** — pick an architecture style justified by the FRAME requirements:

| If requirements say… | Lean toward… |
|----------------------|--------------|
| Small team, early product, unknown domain | **Modular monolith** (default) |
| Independent scaling, org has many teams, clear bounded contexts | **Microservices** |
| Spiky/unpredictable load, event-heavy, glue between systems | **Serverless / event-driven** |
| Heavy async workflows, audit/replay needs | **Event-driven + event sourcing/CQRS** |

**Low-Level Design (LLD)** — apply DDD, SOLID, and appropriate design patterns; choose clean or
hexagonal layering; model errors and concurrency explicitly.

> **Full guides**: [architecture-styles.md](./references/architecture-styles.md) (choose the style,
> C4, ADRs, migration), [microservices-and-distributed.md](./references/microservices-and-distributed.md)
> (Saga/CQRS/outbox/gateway/discovery), [low-level-design.md](./references/low-level-design.md)
> (DDD/SOLID/patterns/concurrency). Default to the **simplest architecture that meets the NFRs** —
> a modular monolith is the right default for most new systems.

---

## Phase 4 — COMMS (API & Real-Time/Eventing Surfaces)

**Goal**: Design the contracts through which clients and services communicate.

- **Synchronous**: REST (default for public/CRUD), GraphQL (flexible client-driven queries),
  gRPC (high-throughput internal RPC). Design versioning, pagination, filtering, idempotency,
  and a consistent error format (RFC 7807).
- **Real-time**: WebSockets (bidirectional), SSE (server→client stream), webhooks (server→server).
- **Asynchronous**: pub/sub, message queues (work distribution) vs event streaming (Kafka; log,
  replay). Decide delivery semantics (at-least/at-most/exactly-once), ordering, idempotent
  consumers, dead-letter queues, and backpressure.

> **Full guides**: [api-design.md](./references/api-design.md),
> [realtime-and-messaging.md](./references/realtime-and-messaging.md)

---

## Phase 5 — BUILD (Production-Ready Implementation)

**Goal**: Implement the design with clean, idiomatic, production-ready code — on any stack.

The build recipe (tech-agnostic): scaffold project structure → externalize config → build the
data-access layer → build the API layer → add authn/authz → validate all input at the boundary
→ handle errors consistently → add structured logging & correlation IDs → write tests →
containerize. Every step maps to concrete code in your chosen stack.

For **choosing** a stack (new project), **detecting** an existing/unknown stack (brownfield), or
applying these steps to **any** framework via its universal building blocks, see the tech-stack
guide's Selection Cheat-Sheet, Decision Framework, and "Detecting & Working With an Existing Stack".

> **Full guides**: [implementation-playbook.md](./references/implementation-playbook.md)
> (the recipe with checkpoints), [tech-stack-guide.md](./references/tech-stack-guide.md)
> (idiomatic snippets for Node, Python, Java/Spring, .NET, Go, Ruby, PHP, Rust)

---

## Phase 6 — HARDEN (Secure, Fast, Scalable, Resilient, Observable)

**Goal**: Turn working code into a system that survives real users, real load, and real attackers.

| Concern | What to do |
|---------|-----------|
| **Security** | OWASP API Top 10 (2023) + Web Top 10: fix BOLA/BFLA, broken auth, injection, SSRF, misconfig; validate input; manage secrets; encrypt in transit & at rest |
| **Caching** | Add the right cache layer & strategy; plan invalidation; prevent stampedes |
| **Scaling** | Make services stateless; load-balance; add read replicas; pool connections; kill N+1; rate-limit |
| **Resilience** | Timeouts, retries with backoff+jitter, circuit breakers, bulkheads, graceful degradation |
| **Observability** | Structured logs, RED/USE metrics, distributed tracing, health checks, alerts |

> **Full guides**: [security.md](./references/security.md), [caching.md](./references/caching.md),
> [scaling-and-performance.md](./references/scaling-and-performance.md),
> [production-readiness.md](./references/production-readiness.md)

---

## Phase 7 — PROVE (Test, Debug, Root-Cause, Ship)

**Goal**: Prove the backend is correct and safe to ship — and when something breaks, fix the
disease, not the symptom.

- **Testing**: build the pyramid (many unit, some integration, few e2e) plus contract tests for
  service boundaries and load tests against the NFR budget.
- **Bug fixing**: reproduce → isolate → trace to **root cause** (5-Whys, blast radius) → fix →
  add a regression test that fails before and passes after → verify no new risk.

> **Full guides**: [testing-strategy.md](./references/testing-strategy.md),
> [bug-detection-and-fixing.md](./references/bug-detection-and-fixing.md),
> [checklist.md](./references/checklist.md)

---

## Backend Concepts Quick Reference

| Concept | Rule of Thumb | Red Flag |
|---------|--------------|----------|
| **Architecture choice** | Simplest style that meets the NFRs; modular monolith by default | Microservices for a 3-person team with no scale need |
| **SQL vs NoSQL** | SQL for relational/transactional; NoSQL for scale/flexible/specific access patterns | Choosing NoSQL to "avoid schemas", then joining in app code |
| **Statelessness** | Keep app servers stateless; push state to DB/cache | Sessions stored in process memory behind a load balancer |
| **Idempotency** | Make writes idempotent (keys) so retries are safe | POST that double-charges on client retry |
| **Caching** | Cache-aside by default; always set a TTL; plan invalidation | Cache with no expiry and no invalidation → stale data |
| **N+1 queries** | Batch/eager-load; verify query count in tests | One query per item in a loop |
| **Consistency** | Pick per use case; strong where money/identity, eventual elsewhere | Distributed transaction across services for a "like" button |
| **AuthZ** | Check object-level ownership on every ID access (prevent BOLA) | Trusting a client-supplied `userId` |
| **Resilience** | Every remote call needs a timeout; add retry + circuit breaker | Unbounded call that hangs the whole request thread |
| **Observability** | Structured logs + metrics + traces with a correlation ID from day one | `print()`/`console.log` with no request context |
| **Config** | 12-Factor: config in env, secrets in a vault | Hardcoded DB URL/API key in source |
| **Migrations** | Backward-compatible, expand→migrate→contract; never destructive in one step | `DROP COLUMN` deployed with code that still reads it |

---

## Anti-Patterns (What NOT to Do)

- ❌ **Designing before framing** — writing code before functional + non-functional requirements exist.
- ❌ **Résumé-driven architecture** — microservices/Kafka/K8s because they're trendy, not because
  requirements demand them. Complexity you don't need is debt you pay forever.
- ❌ **Security/observability last** — bolting them on after launch instead of designing them in.
- ❌ **Distributed monolith** — microservices that must all deploy together and share a database.
- ❌ **Ignoring the data layer** — treating DB choice/schema as an afterthought (hardest to change).
- ❌ **Symptom patching** — fixing the error message, not the cause; no regression test.
- ❌ **Synchronous everything** — blocking calls where async/queue would decouple and protect.
- ❌ **One-size answers** — same recommendation regardless of scale/phase. Always calibrate.

---

## Sources

- [System Design Primer](https://github.com/donnemartin/system-design-primer) — scalability, caching, DB, communication
- [Microservices.io — Pattern Language](https://microservices.io/patterns/index.html) — Chris Richardson's microservice patterns
- [Martin Fowler: Software Architecture Guide](https://martinfowler.com/architecture/) — patterns, monolith-first, microservices
- [OWASP API Security Top 10 (2023)](https://owasp.org/API-Security/editions/2023/en/0x11-t10/) — API-specific risks
- [OWASP Top 10:2025](https://owasp.org/Top10/) — web application security risks
- [OWASP ASVS](https://owasp.org/www-project-application-security-verification-standard/) — verification standard
- [12-Factor App](https://12factor.net/) — cloud-native application methodology
- [Google API Design Guide](https://cloud.google.com/apis/design) & [Microsoft REST API Guidelines](https://github.com/microsoft/api-guidelines) — API conventions
- [RFC 9457 (Problem Details for HTTP APIs)](https://www.rfc-editor.org/rfc/rfc9457) — standard error format
- [Domain-Driven Design (Evans/Vernon)](https://martinfowler.com/tags/domain%20driven%20design.html) — tactical & strategic modeling
- [Release It! (Nygard)](https://pragprog.com/titles/mnee2/release-it-second-edition/) — stability & resilience patterns
- [OpenTelemetry](https://opentelemetry.io/) — logs, metrics, traces
- [The Twelve-Factor App + Beyond (cloud-native)](https://12factor.net/) — config, logs, disposability
- [DORA Metrics](https://dora.dev/) — delivery performance
