# API Design (COMMS)

The API is the contract clients build on — the most expensive thing to get wrong because breaking
it breaks everyone downstream. This reference covers REST, GraphQL, and gRPC; when to use each;
and the details that separate a professional API from an amateur one: versioning, pagination,
idempotency, filtering, and a consistent error format.

> **Rule**: Design the contract first (contract-first), keep it consistent, and version it from day
> one. Consistency across endpoints matters more than any single clever choice.

---

## Choosing a Style

| Style | Shape | Best for | Avoid when |
|-------|-------|----------|-----------|
| **REST** | Resources + HTTP verbs | Public APIs, CRUD, broad client support, caching | Deeply nested graph fetches needing many round-trips |
| **GraphQL** | Single endpoint, client-specified queries | Varied clients, aggregating many sources, avoiding over/under-fetch | Simple CRUD; when caching/rate-limiting simplicity matters |
| **gRPC** | Binary Protobuf over HTTP/2, RPC | High-throughput **internal** service-to-service, streaming | Public browser APIs (needs grpc-web/proxy) |

Common real-world mix: **REST or GraphQL at the edge** (public), **gRPC or async events between
internal services**.

---

## REST — Do It Properly

### Resources & verbs
Model **nouns** (resources), act with HTTP **verbs**:
```
GET    /orders           list orders
POST   /orders           create an order
GET    /orders/{id}      fetch one
PUT    /orders/{id}      full replace (idempotent)
PATCH  /orders/{id}      partial update
DELETE /orders/{id}      delete (idempotent)
GET    /orders/{id}/items  sub-resource
```
- Plural, lowercase, hyphenated collection names (`/purchase-orders`).
- No verbs in paths (`/createOrder` ❌). Use the HTTP method. For genuine actions that don't fit
  CRUD, model a sub-resource or a command (`POST /orders/{id}/cancel`).
- Nest to show ownership but avoid going more than ~2 levels deep.

### Status codes (use the right one)
| Code | Meaning |
|------|---------|
| 200 OK / 201 Created / 204 No Content | Success (201 for create, 204 for empty body) |
| 400 Bad Request | Malformed/invalid input |
| 401 Unauthorized | Missing/invalid authentication |
| 403 Forbidden | Authenticated but not allowed |
| 404 Not Found | Resource (or hidden-for-authz) doesn't exist |
| 409 Conflict | State conflict (duplicate, version mismatch) |
| 422 Unprocessable | Semantically invalid (validation) |
| 429 Too Many Requests | Rate limited (include `Retry-After`) |
| 500 / 502 / 503 | Server fault / bad gateway / unavailable |

### Idempotency & safety
| Method | Safe (no change) | Idempotent (repeat = same effect) |
|--------|------------------|-----------------------------------|
| GET/HEAD | ✅ | ✅ |
| PUT/DELETE | ❌ | ✅ |
| POST | ❌ | ❌ (make it so with idempotency keys) |
| PATCH | ❌ | not necessarily |

For `POST`/payments, support an **`Idempotency-Key`** header: store the key + result; a retry with
the same key returns the original result instead of acting twice. Essential for safe client retries.

### Versioning
Decide on day one; you will need it.
- **URI**: `/v1/orders` (simplest, most visible, cache-friendly) — common choice.
- **Header**: `Accept: application/vnd.api+json;version=1` (cleaner URLs, less visible).
- Rule: **additive changes are non-breaking** (new optional field/endpoint); removing/renaming/
  changing types/making-required is **breaking** → new version. Never break `v1` for existing clients.

### Pagination, filtering, sorting
- **Cursor-based** (preferred for large/real-time sets): opaque cursor, stable under inserts,
  `GET /orders?limit=20&cursor=eyJ...` → returns `next_cursor`. Scales; no deep-offset penalty.
- **Offset/limit** (fine for small, static sets): `?page=3&limit=20` — simple but slow at high
  offsets and skips/duplicates rows when data changes.
- Filtering/sorting: `GET /orders?status=paid&sort=-created_at`. Whitelist filter/sort fields
  (never interpolate them into SQL). Always cap `limit`.

### Error format — RFC 9457 (Problem Details)
Return machine-readable, consistent errors — not ad-hoc strings:
```json
{
  "type": "https://api.example.com/errors/insufficient-funds",
  "title": "Insufficient funds",
  "status": 422,
  "detail": "Wallet balance 12.00 is below the required 30.00.",
  "instance": "/wallets/abc/transfers",
  "errors": [{ "field": "amount", "message": "exceeds available balance" }],
  "traceId": "b7ad6..."
}
```
Include a **stable machine code**/`type`, a human `detail`, field-level errors for validation, and
a `traceId` for support. Never leak stack traces, SQL, or internal paths.

### Other REST essentials
- **HATEOAS** (optional/advanced): include links to related actions/resources.
- **Caching**: `ETag` + `If-None-Match` (304), `Cache-Control`, `Last-Modified` for GETs.
- **Consistency**: pick `snake_case` or `camelCase` for JSON and use it everywhere; ISO-8601 UTC
  timestamps; money as integer minor units or decimal strings (never float).

---

## GraphQL — Power and Its Pitfalls

One endpoint; clients ask for exactly the fields they need, avoiding over-/under-fetching.
```graphql
type Query { order(id: ID!): Order }
type Order { id: ID!, total: Money!, lines: [OrderLine!]!, customer: Customer! }
```
- **Schema-first**, strongly typed; great for many heterogeneous clients aggregating multiple
  sources.
- **The N+1 trap**: resolving `orders { customer { name } }` fires one customer query per order.
  Fix with **DataLoader** (batch + cache per request). This is the #1 GraphQL performance bug.
- **Guardrails**: depth/complexity limiting and cost analysis (a malicious deep/nested query can
  DoS you); persisted queries; disable introspection in production if needed.
- **Caching/rate-limiting** are harder than REST (everything is `POST /graphql`); plan for it.
- Errors come back in a top-level `errors` array (200 OK by default) — design your error contract.

---

## gRPC — Fast Internal RPC

Binary Protobuf over HTTP/2 with generated clients/servers in every language.
```protobuf
service OrderService {
  rpc GetOrder (GetOrderRequest) returns (Order);
  rpc StreamOrders (StreamRequest) returns (stream Order);   // server streaming
}
```
- **Pros**: small/fast payloads, HTTP/2 multiplexing, bidirectional **streaming**, strong contracts
  via `.proto`, polyglot codegen. Excellent for internal service-to-service.
- **Cons**: not natively browser-friendly (needs gRPC-web + proxy); binary payloads are harder to
  debug; less human-readable than JSON.
- **Evolution**: never reuse/renumber field tags; add fields with new numbers; only make optional
  fields (backward compatibility rules).

---

## Contract-First & Governance

- **OpenAPI/Swagger** for REST, **`.proto`** for gRPC, **SDL** for GraphQL: define the contract as
  an artifact, review it, generate server stubs/clients/docs/mocks from it, and validate requests
  against it. Design the contract before implementing.
- **Contract testing** (Pact) so providers can't break consumers unknowingly.
  → [testing-strategy.md](./testing-strategy.md)
- Publish docs; keep a changelog; communicate deprecations with timelines and `Deprecation`/`Sunset`
  headers. Track your API inventory (OWASP API9: shadow/zombie endpoints are a security risk).

---

## Security Touchpoints (see security.md)

Every API design must answer: authN (how identity is proven — tokens/OAuth2), authZ (object- and
function-level checks on **every** request — prevent BOLA/BFLA), input validation at the boundary,
rate limiting/quotas (OWASP API4), and TLS everywhere. → [security.md](./security.md)

---

## Anti-Patterns

- ❌ **Verbs in URLs / everything is POST** — `/getUser`, `/api/do?action=delete`.
- ❌ **200 for everything** — returning `{"error": ...}` with HTTP 200; clients can't tell success
  from failure.
- ❌ **No versioning** — then a breaking change forces every client to update at once.
- ❌ **Offset pagination on huge tables** — `OFFSET 1000000` scans and discards a million rows.
- ❌ **Leaking internals in errors** — stack traces, SQL, file paths in responses.
- ❌ **Inconsistent naming/shapes** — `userId` here, `user_id` there, dates in three formats.
- ❌ **Chatty APIs** — forcing clients to call 5 endpoints to render one screen (consider a BFF/GraphQL).
- ❌ **GraphQL without DataLoader or depth limits** — N+1 queries and query-bomb DoS.
- ❌ **Unbounded list endpoints** — no max `limit`, letting a client pull the whole table.
