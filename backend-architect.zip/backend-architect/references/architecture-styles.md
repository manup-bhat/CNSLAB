# Architecture Styles (HLD) — Choosing the Right Shape

High-Level Design decides the *shape of the system*: how it's split into deployable units, how
they communicate, and where data lives. This reference gives a **decision matrix** to pick a style
from requirements, plus how to evolve an existing system.

> **Rule**: Pick the **simplest architecture that meets the NFRs**. A modular monolith is the
> correct default for most new systems. Distribution is a cost you take on only when a requirement
> (independent scaling, team autonomy, fault isolation) forces it. "Monolith first." — Fowler

---

## The Styles at a Glance

| Style | What it is | Best when | Main cost |
|-------|-----------|-----------|-----------|
| **Monolith** | One deployable app, one DB | Early product, small team, simple domain | Scales as one unit; risky big deploys |
| **Modular monolith** | One deploy, strong internal module boundaries | **Default for most new systems** | Discipline needed to keep modules decoupled |
| **Microservices** | Many independently deployable services, DB-per-service | Independent scaling, many teams, clear bounded contexts | Distributed-systems complexity everywhere |
| **Service-oriented (SOA)** | Coarser services, often shared data/bus | Enterprise integration | Heavier governance |
| **Event-driven** | Components react to events via a broker | Async workflows, decoupling, spiky load | Eventual consistency, harder to trace |
| **Serverless / FaaS** | Functions on managed runtime, scale-to-zero | Spiky/unpredictable load, glue, low ops | Cold starts, vendor lock-in, limits |
| **Layered / N-tier** | Presentation → business → data layers | Almost everything (an *internal* structure) | Can become a "big ball of mud" without discipline |
| **Hexagonal / Clean** | Domain core isolated behind ports/adapters | Long-lived, testable business logic | Upfront structure; see [low-level-design.md](./low-level-design.md) |

Styles compose: a modular monolith can be internally hexagonal and emit events; a microservice
system uses layered/hexagonal design inside each service.

---

## Decision Matrix — From Requirements to Style

Work down these questions (from the FRAME brief):

```
1. Team size & count?
   • 1–2 teams, <~10 engineers         → Monolith / Modular monolith
   • Many autonomous teams              → Microservices become viable

2. Do parts need to scale independently?
   • No — scale as one unit             → Monolith
   • Yes — one part is 100× the load    → Extract that part to a service

3. Are bounded contexts clear and stable?
   • Fuzzy / still discovering domain   → Monolith (don't freeze wrong boundaries)
   • Clear, stable, low-coupling        → Microservices per context

4. Load shape?
   • Steady/diurnal                     → Long-running services
   • Very spiky / event-triggered       → Serverless / event-driven

5. Consistency needs?
   • Strong across the whole domain     → Monolith with one DB (easy transactions)
   • Tolerates eventual between contexts→ Distributed is feasible

6. Operational maturity (CI/CD, observability, on-call)?
   • Low                                → Monolith (microservices need strong ops)
   • High                               → Microservices sustainable
```

**Heuristic**: if you can't clearly justify distribution from the answers above, build a **modular
monolith** and keep the module seams clean so you can extract services *later, when you have
evidence you need to*.

---

## Monolith & Modular Monolith

A monolith is not a dirty word — it's a single deployable unit, which means **simple transactions,
simple debugging, no network between components, one deploy**. Most systems never outgrow a
well-built one.

Make it *modular* so it can grow:
- Organize by **feature/domain module** (e.g., `orders/`, `billing/`, `catalog/`), not by technical
  layer at the top level.
- Each module owns its data and exposes a small internal interface; other modules call that
  interface, **not each other's tables**.
- Enforce boundaries with tooling (package/module visibility, ArchUnit, import-linter, `internal/`
  packages in Go, project references in .NET).
- Keep a single database but give each module its own schema/tables; avoid cross-module foreign
  keys so extraction stays possible.

> A modular monolith gives you 80% of the "microservices" benefit (clear boundaries, team
> ownership) with 20% of the cost (no network, no distributed transactions).

---

## Microservices

Independently deployable services, each owning its data. Powerful at organizational scale,
punishing when adopted prematurely.

**Prerequisites** (have these *before* going micro):
- Solid CI/CD, containerization, and automated deploys.
- Observability: centralized logs, metrics, **distributed tracing** (you can't debug across
  services without it).
- Clear bounded contexts (do Domain-Driven Design first).
- Teams organized to own services end-to-end.

**Core rules**:
- **Database per service** — no shared database; a service's data is private, accessed only via its
  API/events. Sharing a database recreates a monolith with network latency (a "distributed monolith").
- Communicate via well-defined contracts (sync REST/gRPC or async events).
- Design for partial failure: timeouts, retries, circuit breakers everywhere.
- Prefer **choreography (events)** for loose coupling; use **orchestration (Saga)** when a workflow
  needs a coordinator. → [microservices-and-distributed.md](./microservices-and-distributed.md)

**The distributed-monolith trap** (❌): services that must be deployed together, share a database,
or call each other synchronously in long chains. You get all the cost of distribution and none of
the independence. If two services always change together, they should be one service.

---

## Event-Driven Architecture

Components communicate by producing and consuming **events** through a broker, instead of calling
each other directly.

- **Decoupling**: producers don't know consumers. Add a new consumer without touching producers.
- **Patterns**: event notification, event-carried state transfer, **event sourcing** (persist state
  as a log of events), **CQRS** (separate write and read models).
  → [microservices-and-distributed.md](./microservices-and-distributed.md)
- **Trade-offs**: eventual consistency, harder end-to-end tracing, and you must design for
  duplicate/out-of-order events (idempotent consumers). → [realtime-and-messaging.md](./realtime-and-messaging.md)

Great for: async workflows (order → fulfillment → shipping), fan-out (one event, many reactions),
buffering spikes, and integrating heterogeneous systems.

---

## Serverless / FaaS

Managed functions that scale automatically (including to zero) and bill per invocation.

- **Good for**: spiky/unpredictable load, event processing, cron/glue jobs, low-ops small services,
  APIs behind a gateway.
- **Watch out for**: **cold starts** (latency on first hit), execution time/memory limits, statelessness
  (no local state between invocations — use external stores), per-invocation cost at high steady
  volume (can exceed a always-on server), and vendor lock-in.
- **Pattern**: API Gateway → function → managed data store/queue. Keep functions small and
  single-purpose; push shared logic into layers/libraries.

---

## Documenting Architecture — C4 & ADRs

- **C4 model** — describe the system at four zoom levels: **Context** (system + external actors) →
  **Container** (deployable units: apps, DBs, queues) → **Component** (major parts inside a
  container) → **Code** (classes, only when useful). Draw Context + Container for every design.
- **Architecture Decision Records (ADRs)** — one short markdown file per significant decision:
  ```
  # ADR-007: Use a modular monolith for the ordering system
  Status: Accepted
  Context: 4 engineers, unclear domain boundaries, <500 QPS, strong consistency on orders.
  Decision: Single deployable, feature-modular, one Postgres with per-module schemas.
  Consequences: Simple transactions & deploys now; module seams kept clean to allow
                extracting a service later if a module needs independent scale.
  Revisit when: any module exceeds ~5k QPS or needs a separate release cadence.
  ```
ADRs make designs reviewable and preserve the *why* for future engineers.

---

## Evolving an Existing System (Brownfield)

Don't rewrite; evolve incrementally.

- **Strangler Fig**: put a facade/router in front of the legacy system; build new functionality (or
  reimplement pieces) behind it and route traffic over gradually until the old system is "strangled".
  Low-risk, reversible, no big-bang cutover.
- **Anti-Corruption Layer (ACL)**: a translation layer between your clean new model and a messy
  legacy/third-party model, so their design doesn't leak into yours.
- **Branch by abstraction**: introduce an abstraction over the thing you're replacing, swap
  implementations behind it, then remove the old one.
- **Extract a service** from a modular monolith only when you have evidence (independent scaling,
  team ownership, deploy-cadence conflict) — carve along an existing module seam.

> Sequence a monolith→microservices migration by **business value and pain**: extract the module
> that most needs independent scaling or the fastest release cadence first, not the easiest one.

---

## Anti-Patterns

- ❌ **Résumé-driven architecture** — microservices/Kafka/K8s chosen for the CV, not the requirements.
- ❌ **Distributed monolith** — services sharing a DB or deployed in lockstep.
- ❌ **Premature microservices** — distributing before you have CI/CD, tracing, and clear contexts.
- ❌ **Big-bang rewrite** — replacing a working system all at once instead of strangling it.
- ❌ **Nano-services** — services so fine-grained that a single request fans out across dozens of hops.
- ❌ **Shared mutable database** as an integration point between services.
- ❌ **No ADRs** — nobody remembers why the architecture is the way it is six months later.
