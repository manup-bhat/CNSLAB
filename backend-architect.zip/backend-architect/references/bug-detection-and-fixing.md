# Bug Detection & Fixing (PROVE)

Finding a backend bug, understanding *why* it happens, and fixing the **cause** — not the symptom —
without introducing new ones. This reference gives a disciplined debugging method, a catalog of the
bug classes that actually bite backends, and the rules for a safe, verified fix.

> **Rule**: Reproduce first, fix the root cause, and prove it with a regression test that fails
> before the fix and passes after. A "fix" you can't reproduce and can't test is a guess.

---

## The Debugging Loop — REPRODUCE · ISOLATE · ROOT · FIX · VERIFY

```
 REPRODUCE ─→ ISOLATE ─→ ROOT ─→ FIX ─→ VERIFY
  make it     narrow to  find the  fix the  regression test +
  happen      the code   true      cause,   no new risk +
  reliably    path/data  cause     minimal  observability
             (bisect)   (5-whys)   change
```

| Stage | Mandate | Gate |
|-------|---------|------|
| **REPRODUCE** | Make the bug happen on demand (test/script/steps) | "Can I trigger it reliably?" |
| **ISOLATE** | Narrow to the smallest code path + input that triggers it | "Do I know exactly where and with what data?" |
| **ROOT** | Find the underlying cause, not the surface symptom | "Would fixing this prevent the whole class, not one instance?" |
| **FIX** | Smallest correct change addressing the cause | "Is this the cause, minimally changed?" |
| **VERIFY** | Regression test + no new risk + observability | "Does a test fail before and pass after? Anything else affected?" |

> **Prime directive**: no fix without a reproduction and a regression test. Symptom-patching creates
> whack-a-mole bugs.

---

## Stage 1 — Reproduce

You cannot fix what you cannot reproduce.
- Gather the exact inputs, state, and environment from the report/logs/trace.
- Turn it into a **failing test** or a minimal script. This test becomes the regression test later.
- If it's intermittent, it's likely **concurrency, state, time, or environment** dependent (see the
  catalog). Increase load/iterations, add logging, or run with a race detector to force it out.
- Use the **correlation id** from logs/traces to reconstruct the exact request path.

---

## Stage 2 — Isolate

- **Bisect**: narrow by halves — which layer (API/service/domain/data)? which input? `git bisect`
  to find the commit that introduced it.
- **Read the actual code and data** on the failing path — don't assume from names. Verify each
  assumption against ground truth (log the real values, inspect the real row).
- Reduce to the **minimal reproduction**: strip everything that isn't required to trigger it.

---

## Stage 3 — Root Cause (fix the disease)

Ask **"why"** repeatedly (5 Whys) until you reach a cause that, if fixed, prevents the whole class:
```
Symptom: API returns 500 on checkout.
  Why? NullPointer reading order.customer.
  Why? customer was null.
  Why? The customer lookup returned nothing.
  Why? The id was a soft-deleted customer.
  Why? The query didn't filter deleted_at, and checkout doesn't validate customer state.
Root cause: missing state validation + query ignores soft-delete → fix both, not just the null check.
```
- **Same-pattern sweep**: if this bug exists here, grep for the same pattern elsewhere — it's rarely
  unique.
- **Blast radius**: what else depends on this code/data? Could the fix affect other callers?

---

## Backend Bug Class Catalog

### Concurrency
| Bug | Symptom | Cause / Fix |
|-----|---------|-------------|
| **Race condition** | Intermittent wrong results under load | Shared mutable state without sync → lock/atomic/immutability, or don't share |
| **Deadlock** | Requests hang; DB deadlock errors | Locks acquired in different orders → consistent lock ordering, short transactions |
| **Lost update** | One write silently overwrites another | Read-modify-write race → `SELECT FOR UPDATE` or optimistic version check |
| **Double-processing** | Duplicate charges/emails | Non-idempotent op + retry/redelivery → idempotency keys |

### Resource & memory
| Bug | Symptom | Cause / Fix |
|-----|---------|-------------|
| **Connection leak** | Pool exhausted, hangs over time | Connections not released → scope-bound cleanup (`with`/`using`/`defer`) |
| **Memory leak** | RSS grows until OOM/restart | Unbounded cache/collection, listeners not removed, closures retaining refs |
| **Goroutine/thread leak** | Thread/goroutine count climbs | Blocked forever on channel/lock → context cancellation, timeouts |
| **File/socket leak** | "Too many open files" | Handles not closed |

### Data & logic
| Bug | Symptom | Cause / Fix |
|-----|---------|-------------|
| **N+1 queries** | Endpoint slow, DB busy | Query per item → batch/eager-load; assert query count |
| **Off-by-one / boundary** | Wrong pagination, missing/extra item | Inclusive/exclusive bounds → test boundaries |
| **Float money** | Rounding errors in totals | Float arithmetic → decimal/integer cents |
| **Timezone/DST** | Wrong times, off-by-hours | Naive local time → store UTC, convert at edges |
| **Null propagation** | NullPointer/AttributeError | Unchecked nullable through call chain → validate/Optional/typed |
| **Error swallowing** | Silent failure, no logs | Empty catch → handle/log/rethrow with context |
| **Wrong comparison/logic inversion** | Subtle wrong behavior | `>=` vs `>`, `&&` vs `||`, negation → test the truth table |

### Transaction & consistency
| Bug | Symptom | Cause / Fix |
|-----|---------|-------------|
| **Partial write** | Inconsistent state after failure | Multi-step without transaction → wrap in one, or Saga + compensation |
| **Dual write** | Event/DB out of sync | DB + broker written separately → outbox pattern |
| **Stale cache** | Old data after update | No invalidation → delete-on-write + TTL |
| **Replica lag read** | User can't see own write | Read from lagging replica → route read-your-writes to primary |

### Boundary & input
Missing validation → 500s/crashes on malformed input; unbounded input → DoS; injection →
[security.md](./security.md). Validate at the boundary; treat all input as hostile.

---

## Observability-Driven Debugging

Production bugs are debugged through telemetry, not a debugger:
- **Logs**: filter by correlation id to see the full request; look for the first ERROR/WARN, not
  just the last.
- **Metrics**: when did error rate/latency spike? What deploy/traffic change correlates?
- **Traces**: which span failed or was slow? Which downstream call? → [production-readiness.md](./production-readiness.md)
- **The bug you can't see** usually means missing instrumentation — add it (that's part of the fix).

---

## Stage 4 — Fix (minimal, correct, at the cause)

- Make the **smallest change** that addresses the **root cause**. Resist unrelated refactors in a
  bugfix (separate PR).
- Fix the **whole class** where cheap (the same-pattern sweep), not only the reported instance.
- Preserve behavior and contracts; don't fix a bug by breaking an API.
- Consider concurrency and idempotency in the fix itself (the fix runs in production, under load).

---

## Stage 5 — Verify (prove it, and check for new risk)

- **Regression test**: the reproduction from Stage 1, now committed — it must **fail before** the
  fix and **pass after**. This is non-negotiable.
- **Blast-radius check**: run the full suite; review other callers of the changed code.
- **Add/adjust observability** so if it recurs, you'll see it (a metric/log/alert).
- **Root-cause note**: record what happened and why (for the PR / postmortem) so the team learns.

```
FIX RECORD
  Symptom:      <what users saw>
  Reproduction: <test/steps>
  Root cause:   <the real cause, via 5-whys>
  Fix:          <what changed, and why minimal>
  Class sweep:  <other places checked/fixed>
  Regression:   <the test name that guards it>
  Prevention:   <lint/type/alert/process change so the class can't return>
```

---

## Prevention (stop the class from returning)

The best fix removes the whole category:
- Add a **lint rule / static analysis** (e.g., ban `float` for money, require closing resources).
- Strengthen **types** (non-null types, value objects, `Result`) so the bug can't be expressed.
- Add the missing **test at the right level** and a **metric/alert** for the symptom.
- Fix the **process** if it was systemic (missing review step, no load test).

---

## Anti-Patterns

- ❌ **Fixing without reproducing** — guessing; you won't know if it worked.
- ❌ **Symptom patching** — adding a null check instead of fixing why it's null.
- ❌ **No regression test** — the bug returns on the next refactor.
- ❌ **Debugging from names/assumptions** — not reading the actual code/data on the path.
- ❌ **Scope creep in a bugfix** — bundling refactors that obscure the fix and add risk.
- ❌ **Ignoring the class** — fixing one instance while identical bugs lurk elsewhere.
- ❌ **Swallowing the error to make it "go away"** — hiding the failure instead of fixing it.
- ❌ **`console.log` and delete** — leaving no lasting test/metric so it can't be caught next time.
