# Caching (HARDEN)

Caching is the highest-leverage performance tool — and the source of the hardest bugs ("there are
only two hard things in CS: cache invalidation and naming things"). This reference covers where to
cache, which strategy to use, how to invalidate, and how to avoid the classic failure modes.

> **Rule**: Every cache entry needs a **TTL** and an **invalidation plan**. A cache without
> expiry serves stale data forever; a cache without an invalidation story silently corrupts reads.

---

## Where to Cache (layers, client → server)

| Layer | What it caches | Tool | Notes |
|-------|----------------|------|-------|
| **Client / browser** | Responses, assets | HTTP `Cache-Control`, `ETag` | Cheapest hit — never reaches you |
| **CDN / edge** | Static + cacheable dynamic responses | CloudFront, Cloudflare, Fastly | Offloads origin; geo-close to users |
| **Reverse proxy** | Rendered responses, fragments | Nginx, Varnish | In front of app servers |
| **Application** | Objects, query results, computed values | **Redis**, Memcached | The workhorse; shared across instances |
| **Database** | Query/plan/buffer caches | Built into the DB | Tune, but don't rely on it alone |
| **In-process / local** | Hot config, small hot data | LRU map in memory | Fastest, but per-instance & not shared |

Prefer a **shared** cache (Redis) over per-process memory once you run more than one instance —
otherwise each node has a different view and hit rates drop.

---

## What to Cache

- **Read-heavy, expensive-to-compute, tolerant-of-slight-staleness** data (the 80/20 hot set).
- Good candidates: user sessions, rendered pages/fragments, expensive aggregations, reference/
  lookup data, third-party API responses, computed permissions.
- **Do not cache**: data that must be exact in real time (account balance at point of charge),
  per-request unique data (no reuse), or anything you can't invalidate correctly.

---

## Caching Strategies (read & write patterns)

| Strategy | How it works | Pros | Cons / when |
|----------|--------------|------|-------------|
| **Cache-aside (lazy)** | App checks cache; on miss, loads from DB and populates cache | Simple, only caches what's used | First hit is slow; risk of stale after writes → **default** |
| **Read-through** | Cache library loads from DB on miss transparently | App code simpler | Needs a caching layer that supports it |
| **Write-through** | Write goes to cache **and** DB synchronously | Cache always fresh | Slower writes; caches data that may never be read |
| **Write-behind (write-back)** | Write to cache, async flush to DB | Fast writes, absorbs bursts | **Data loss if cache dies** before flush; complex |
| **Refresh-ahead** | Proactively refresh hot keys before they expire | Low latency on hot keys | Wastes work if prediction is wrong |

**Cache-aside** is the sensible default. Combine with a TTL and explicit invalidation on write.

```python
def get_user(uid):
    key = f"user:{uid}"
    if (u := cache.get(key)) is not None:
        return u                       # hit
    u = db.get_user(uid)               # miss → load
    if u: cache.set(key, u, ttl=300)   # populate with TTL
    return u

def update_user(uid, data):
    db.update_user(uid, data)
    cache.delete(f"user:{uid}")        # invalidate on write (don't leave stale)
```

---

## Invalidation — The Hard Part

Pick a strategy and be consistent:
- **TTL (expiry)**: simplest; bounds staleness. Always set one, even with explicit invalidation, as
  a safety net. Choose TTL by how stale the data may acceptably be.
- **Write invalidation**: delete/update the key when the underlying data changes. Prefer
  **delete-on-write** (then repopulate lazily) over update-in-place — fewer race conditions.
- **Versioned/keyed**: bake a version into the key (`user:42:v7`); bump the version to invalidate a
  whole set without scanning.
- **Event-driven**: invalidate on domain events (the source of truth publishes "user updated").

**Consistency caveat**: cache and DB can diverge under concurrent write+read. For correctness-
critical data, prefer short TTLs, delete (not write) on change, and read from the source when it
must be exact.

---

## Classic Failure Modes (and fixes)

| Problem | What happens | Fix |
|---------|--------------|-----|
| **Cache stampede / thundering herd** | A hot key expires; thousands of requests hit the DB at once | Lock/single-flight so one request repopulates; stagger TTLs with jitter; refresh-ahead |
| **Cache penetration** | Requests for keys that don't exist bypass cache every time (often malicious) | Cache negative results (short TTL); validate/whitelist inputs; Bloom filter |
| **Cache avalanche** | Many keys expire simultaneously → DB spike | Add random jitter to TTLs; tiered expiry |
| **Hot key** | One key gets disproportionate traffic, overloads a node | Local (in-process) cache in front; replicate the key; shard |
| **Stale data** | Cache not invalidated on write | Delete-on-write + TTL; event-driven invalidation |
| **Big key** | One huge value blocks the cache/network | Split it; compress; paginate |

**Single-flight example (prevent stampede)**:
```
on miss for hot key:
  acquire short lock for key
    if got lock:  load from DB, set cache, release
    else:         wait briefly and re-read cache (someone else is loading)
```

---

## Redis — Beyond a Key-Value Cache

Redis is the default application cache and does much more:
- **Data structures**: strings, hashes, lists, sets, sorted sets (leaderboards, rate limiters),
  streams, HyperLogLog, geospatial.
- **Sessions** and **feature flags** (shared across instances).
- **Distributed lock** (with care): `SET key val NX PX ttl`; for stronger guarantees use Redlock —
  but understand its debated limits; prefer a DB lock for correctness-critical mutual exclusion.
- **Rate limiting**: `INCR` + `EXPIRE`, or token-bucket via Lua for atomicity.
- **Pub/Sub** and **Streams** for lightweight messaging (see [realtime-and-messaging.md](./realtime-and-messaging.md)).
- **Eviction policy**: set `maxmemory` + a policy (`allkeys-lru`, `allkeys-lfu`, `volatile-ttl`).
  Know that Redis will evict under pressure — don't treat a cache as durable storage.
- **Persistence** (RDB/AOF) exists but a cache should be treated as **rebuildable**, not a database.

---

## HTTP Caching (let the network cache for you)

- `Cache-Control: public, max-age=300` for cacheable GETs; `private`/`no-store` for user-specific/
  sensitive responses.
- **`ETag`** + `If-None-Match` → return `304 Not Modified` (saves bandwidth & compute).
- `Vary` on headers that change the response (e.g., `Accept-Encoding`, `Authorization`).
- Use a CDN for static assets and cacheable API responses; set correct headers so it caches
  correctly (and doesn't cache private data!).

---

## Cache Metrics to Watch

- **Hit ratio** (aim high for the hot set; a low ratio means the cache isn't earning its keep).
- **Latency** (p99 of cache ops), **evictions** (too-small cache), **memory usage**, **connection
  count**. Alert on a sudden hit-ratio drop (often a deploy that changed keys, or an outage).

---

## Anti-Patterns

- ❌ **No TTL** — entries live forever; stale data is served indefinitely.
- ❌ **No invalidation on write** — the cache and DB silently diverge.
- ❌ **Update-in-place on write** under concurrency — prefer delete-then-lazy-load.
- ❌ **Per-process cache behind a load balancer** for shared data — inconsistent views, low hit rate.
- ❌ **Caching sensitive/per-user data in a shared/CDN cache** — data leaks across users.
- ❌ **Treating Redis as the source of truth** — it can evict and lose data under pressure.
- ❌ **No stampede protection on hot keys** — expiry triggers a DB thundering herd.
- ❌ **Caching to hide an unindexed query** — fix the query/index first; cache the *result*, not the bug.
