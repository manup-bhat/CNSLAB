# Checklists (GATE)

Consolidated, checkbox-style gates for each phase of the backend loop. Use them as a fast
verification pass — a "did I miss anything?" review before moving on or shipping. Each links back to
the reference with the full reasoning.

> **How to use**: For a full design/build, walk every checklist in order. For a focused task, run
> the relevant one(s). A checked box means *verified*, not *intended*.

---

## FRAME — Requirements & Estimation
→ [requirements-and-estimation.md](./requirements-and-estimation.md)
- [ ] Functional requirements listed; **critical paths** (money/identity/data) identified.
- [ ] NFRs **quantified**: peak & avg QPS, read:write ratio, p95/p99 latency budget.
- [ ] Data volume + growth + retention estimated; storage sized (with replicas/indexes/headroom).
- [ ] Availability target (nines) and consistency need chosen **per data set**.
- [ ] Capacity estimate done (traffic, storage, bandwidth, cache/memory).
- [ ] Constraints and **assumptions** written down explicitly.
- [ ] (Brownfield) Existing system mapped: endpoints, data, dependencies, current SLOs, pain points.

## MODEL — Data & Databases
→ [data-modeling-and-databases.md](./data-modeling-and-databases.md)
- [ ] Domain modeled: entities, value objects, aggregates, relationships, access patterns.
- [ ] Store chosen **per data set** by access pattern (SQL default; NoSQL justified by need).
- [ ] Schema designed; correct types (decimal for money, UTC timestamps); constraints enforced.
- [ ] Indexes match query patterns; `EXPLAIN` checked on hot queries; no needless indexes.
- [ ] Transaction/consistency boundaries defined; isolation level chosen deliberately.
- [ ] Migration approach is versioned and backward-compatible (expand→migrate→contract).

## DESIGN — Architecture (HLD)
→ [architecture-styles.md](./architecture-styles.md), [microservices-and-distributed.md](./microservices-and-distributed.md)
- [ ] Architecture style chosen from requirements (default: **modular monolith** unless justified).
- [ ] Every structural choice traces to a requirement; nothing over-engineered.
- [ ] Component/data-flow diagram (C4 context + container) drawn.
- [ ] Key decisions recorded as **ADRs** with trade-offs and "revisit-when".
- [ ] (Distributed) DB-per-service; no shared DB; async where it decouples; idempotent consumers.
- [ ] (Distributed) Cross-service consistency via Saga/CQRS/outbox as needed; compensations defined.
- [ ] (Brownfield) Migration via strangler/anti-corruption layer, not a big-bang rewrite.

## DESIGN — Code (LLD)
→ [low-level-design.md](./low-level-design.md)
- [ ] Layering keeps the domain free of framework/IO; dependencies point inward.
- [ ] SOLID applied; DI via constructor/container; interfaces at boundaries.
- [ ] Errors modeled (domain errors vs faults); no swallowed exceptions.
- [ ] Concurrency model understood; shared state guarded; idempotency where retried.
- [ ] Aggregates small; one aggregate per transaction; reference others by id.

## COMMS — API & Messaging
→ [api-design.md](./api-design.md), [realtime-and-messaging.md](./realtime-and-messaging.md)
- [ ] API style chosen (REST/GraphQL/gRPC) fits the clients and use case.
- [ ] Correct verbs & status codes; consistent naming; **versioned from day one**.
- [ ] Pagination (cursor for large sets), filtering/sorting whitelisted, `limit` capped.
- [ ] Idempotency keys for unsafe retryable writes (payments).
- [ ] Consistent error format (RFC 9457); no internals leaked; `traceId` included.
- [ ] Contract defined as an artifact (OpenAPI/proto/SDL); contract tests at boundaries.
- [ ] (Real-time) WS auth at handshake; shared backplane; heartbeats; cleanup on disconnect.
- [ ] (Async) Delivery semantics known; idempotent consumers; **DLQ** + retry/backoff; outbox for dual-write.

## BUILD — Implementation
→ [implementation-playbook.md](./implementation-playbook.md), [tech-stack-guide.md](./tech-stack-guide.md)
- [ ] Project structured by feature then layer; composition root wires dependencies.
- [ ] Config from env, validated at startup; **no secrets in code**.
- [ ] Data layer uses parameterized queries/ORM + connection pool.
- [ ] Controllers thin; business logic in the domain/application layer.
- [ ] Explicit request/response **DTOs** (no exposing ORM entities; no mass assignment).
- [ ] **All input validated at the boundary**; unknown fields rejected.
- [ ] AuthN in middleware; **object-level + function-level authz** on every protected action.
- [ ] Global error handler; structured logs with correlation id (no secrets/PII).
- [ ] Idiomatic to the chosen stack; no fighting the framework.

## HARDEN — Security
→ [security.md](./security.md)
- [ ] **BOLA**: object ownership checked on every id-based access (no trusting client ids).
- [ ] **BFLA**: role/permission checked on every function, especially admin; deny by default.
- [ ] Injection prevented (parameterized queries; no shell string-building).
- [ ] AuthN robust: strong password hashing (argon2/bcrypt); short-lived tokens verified fully.
- [ ] Rate limits / quotas / payload & timeout limits (OWASP API4) in place.
- [ ] SSRF protection on user-supplied URLs; internal ranges blocked.
- [ ] Secrets in a vault; TLS everywhere; sensitive data encrypted at rest.
- [ ] Security headers + strict CORS (no `*` with credentials); secure cookies.
- [ ] Dependencies scanned for CVEs; containers run as non-root.
- [ ] Prod errors generic; verbose/debug disabled.

## HARDEN — Caching, Scaling, Performance
→ [caching.md](./caching.md), [scaling-and-performance.md](./scaling-and-performance.md)
- [ ] App servers **stateless**; sessions/state in a shared store; uploads in object storage.
- [ ] Cache layer/strategy chosen; **every entry has a TTL + invalidation plan**; stampede protection.
- [ ] Load balancing + health checks; multiple LBs (no single point of failure).
- [ ] DB scaling path clear (indexes → pooling → cache → replicas → shard-if-forced).
- [ ] **No N+1** (query counts asserted in tests); result sets paginated.
- [ ] Connection pools sized; resources released (no leaks).
- [ ] Rate limiting / load shedding / backpressure protect against overload.
- [ ] Slow/bursty work offloaded to async workers.

## HARDEN — Production Readiness
→ [production-readiness.md](./production-readiness.md)
- [ ] 12-Factor: config in env, stateless processes, logs to stdout, fast startup.
- [ ] Structured logs + **RED/USE metrics** + distributed tracing; SLO-based alerts.
- [ ] Liveness/readiness probes; **graceful shutdown** on SIGTERM.
- [ ] **Timeouts + retries(+jitter) + circuit breakers** on all outbound calls; bulkheads where needed.
- [ ] Feature flags for risky rollouts / kill switches.
- [ ] CI gates (tests + security scan); immutable image; deploy + rollback strategy; safe migrations.
- [ ] Backups with **tested restore**; RPO/RTO defined; DR runbook exists.

## PROVE — Testing
→ [testing-strategy.md](./testing-strategy.md)
- [ ] Test pyramid: many unit (domain), some integration (real DB via Testcontainers), few e2e.
- [ ] Critical paths (money/auth/data) covered including **edge cases** and error paths.
- [ ] Integration tests hit real dependencies; **query counts asserted** (N+1 guard).
- [ ] Contract tests on service/API/event boundaries.
- [ ] Load test validates the p95/p99 + throughput budget on production-like data.
- [ ] Tests are fast, deterministic, isolated; run as a **CI merge gate**; no ignored flaky tests.

## PROVE — Bug Fixing
→ [bug-detection-and-fixing.md](./bug-detection-and-fixing.md)
- [ ] Bug **reproduced** reliably (as a failing test/script).
- [ ] **Root cause** found (5-Whys), not just the symptom.
- [ ] Same-pattern **class sweep** done; blast radius reviewed.
- [ ] Minimal fix at the cause; contracts preserved.
- [ ] **Regression test** fails before, passes after; full suite green.
- [ ] Observability added so a recurrence is visible; root-cause note recorded.

---

## Pre-Ship Gate (the short list before real traffic)

- [ ] Requirements met; critical paths demoed on realistic cases.
- [ ] Input validated; authZ (object + function) enforced; secrets externalized.
- [ ] Security scan clean; injection/BOLA/BFLA/SSRF checks done.
- [ ] Observability live (logs+metrics+traces+correlation id); health checks + graceful shutdown.
- [ ] Timeouts/retries/circuit breakers on remote calls; rate limiting on.
- [ ] Tests green in CI; critical-path + regression coverage; load budget met.
- [ ] Safe, backward-compatible migration; deploy + **rollback** ready.
- [ ] Backups + tested restore; alerts wired to SLOs.
- [ ] No secrets in code/logs; config per-env; runs as non-root.
- [ ] ADRs updated; docs/changelog current; API inventory has no shadow endpoints.

---

## PR Review Gate (reviewing backend changes)

- [ ] Change is scoped and minimal; no unrelated refactors bundled in.
- [ ] Business logic in the right layer; controllers thin; DTOs used.
- [ ] Input validated; authZ correct; no trusting client-supplied identity.
- [ ] No string-built SQL/commands; no secrets; errors handled (not swallowed).
- [ ] Tests added/updated for the change (incl. regression for bugfixes); query counts sane.
- [ ] Backward-compatible API/schema/migration; observability for new paths.
- [ ] Idiomatic to the stack; names clear; complexity reasonable.
