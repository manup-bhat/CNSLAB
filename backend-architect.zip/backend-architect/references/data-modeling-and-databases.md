# Data Modeling & Databases (MODEL)

Most backend complexity is data complexity, and data decisions are the hardest to reverse. This
reference covers modeling the domain, choosing SQL vs NoSQL by access pattern, schema design,
indexing, transactions/consistency, and scaling the data layer (replication, sharding).

> **Rule**: Choose a database by your **access patterns and consistency needs**, not by fashion.
> "How will this data be read and written, and how consistent must it be?" answers 90% of it.

---

## Step 1 — Model the Domain First

Before choosing a store, model the domain (see also [low-level-design.md](./low-level-design.md)):
- **Entities**: things with identity (User, Order, Payment).
- **Value objects**: defined by their attributes, no identity (Money, Address, DateRange).
- **Aggregates**: a cluster of entities/values with one root and a consistency boundary — you
  load, save, and enforce invariants at the aggregate level (e.g., `Order` + its `OrderLines`).
- **Relationships & cardinality**: 1:1, 1:N, N:M; ownership and lifecycle.
- **Access patterns**: for each entity, list how it is queried and written (by id? by user? range
  scan? full-text? aggregation?). **This list decides the database.**

---

## Step 2 — SQL vs NoSQL Decision

| Choose SQL (relational) when… | Choose NoSQL when… |
|-------------------------------|--------------------|
| Data is relational; you need JOINs | Access is by key or single document/partition |
| You need ACID transactions across rows/tables | You need massive write throughput / horizontal scale |
| Schema is stable and worth enforcing | Schema is flexible / evolving / sparse |
| Complex ad-hoc queries & reporting | Specific, known query patterns at huge scale |
| Strong consistency is required | Eventual consistency is acceptable |
| Team/tooling maturity, clear scaling path | Data shape fits a specialized model (graph, time-series, wide-column) |

**Default**: start with a mature relational database (PostgreSQL is an excellent default — it also
does JSON, full-text, and geospatial). Add NoSQL only for data whose access pattern SQL serves
poorly. Most systems are **polyglot**: relational core + Redis cache + maybe a search/analytics store.

### NoSQL family — pick by data shape
| Type | Abstraction | Good for | Examples |
|------|-------------|----------|----------|
| **Key-value** | Hash table | Sessions, cache, feature flags, O(1) lookups | Redis, DynamoDB, Memcached |
| **Document** | KV with structured docs | Flexible entities, content, catalogs | MongoDB, Couchbase, Firestore |
| **Wide-column** | Nested map by row+column | Huge write volume, time-series at scale | Cassandra, HBase, Bigtable |
| **Graph** | Nodes + edges | Relationships/traversals (social, fraud) | Neo4j, Neptune |
| **Time-series** | Timestamped points | Metrics, IoT, events | TimescaleDB, InfluxDB |
| **Search** | Inverted index | Full-text, faceted search | Elasticsearch, OpenSearch |
| **Vector** | Embedding similarity | Semantic search, RAG/AI | pgvector, Pinecone, Milvus |

---

## Step 3 — Schema & Modeling Best Practices

### Relational
- **Normalize first (3NF)**, denormalize deliberately later where reads demand it. Premature
  denormalization creates update anomalies.
- Use the **right types**: `DECIMAL`/`NUMERIC` for money (never float), `TIMESTAMPTZ` for time
  (store UTC), native `UUID`/`BIGINT` for keys, `BOOLEAN`, enums/lookup tables for fixed sets.
- **Constraints are free correctness**: `NOT NULL`, `UNIQUE`, `CHECK`, `FOREIGN KEY`. Enforce
  invariants in the DB, not only in app code.
- **Primary keys**: prefer surrogate keys (auto-increment `BIGINT` or UUIDv7). UUIDv4 hurts index
  locality; UUIDv7/ULID are time-ordered and index-friendly.
- **Soft deletes** (`deleted_at`) vs hard deletes — decide per table; index around it.
- Add `created_at`/`updated_at` everywhere; they pay for themselves in debugging.

### Document (NoSQL)
- **Model for the query**: embed data read together; reference data read separately or shared.
- Watch the **unbounded array** anti-pattern (a document that grows forever, e.g. all comments in
  a post) — it hits document-size limits and rewrites the whole doc on each append.
- Duplicate deliberately for read performance, and own the consistency cost (update all copies).

---

## Step 4 — Indexing

Indexes turn O(n) scans into O(log n) lookups — and slow every write a little. Index with intent.

| Concept | Guidance |
|---------|----------|
| **What to index** | Columns in `WHERE`, `JOIN`, `ORDER BY`, `GROUP BY`, and foreign keys |
| **Composite index** | Order matters — **leftmost prefix** rule; put equality columns before range |
| **Covering index** | Include all columns a query needs so it never touches the table (index-only scan) |
| **Selectivity** | High-cardinality columns benefit most; indexing a boolean rarely helps |
| **Partial index** | Index a subset (`WHERE deleted_at IS NULL`) to shrink and speed it |
| **Don't over-index** | Each index costs write time + storage; drop unused ones |

**Always read the query plan** (`EXPLAIN ANALYZE` in Postgres/MySQL). A "Seq Scan" on a large
table in a hot query is a red flag. Add the index, re-check the plan, confirm it's used.

```sql
EXPLAIN ANALYZE
SELECT id, total FROM orders
WHERE user_id = $1 AND status = 'paid'
ORDER BY created_at DESC LIMIT 20;
-- Wants a composite index: (user_id, status, created_at DESC)
```

---

## Step 5 — Transactions, ACID & Isolation

**ACID** (relational transactions):
- **Atomicity** — all-or-nothing.
- **Consistency** — moves the DB between valid states (constraints hold).
- **Isolation** — concurrent transactions don't corrupt each other.
- **Durability** — committed data survives crashes.

### Isolation levels & the anomalies they prevent
| Level | Dirty read | Non-repeatable read | Phantom | Notes |
|-------|-----------|---------------------|---------|-------|
| Read Uncommitted | possible | possible | possible | Rarely used |
| Read Committed | prevented | possible | possible | **Postgres default** |
| Repeatable Read | prevented | prevented | possible* | **MySQL/InnoDB default** (*prevents phantoms via gap locks) |
| Serializable | prevented | prevented | prevented | Safest, most contention |

- Keep transactions **short**; never do network/IO calls inside a DB transaction.
- Beware **lost updates**: read-modify-write races. Use `SELECT ... FOR UPDATE` (pessimistic) or a
  version column with a `WHERE version = $n` check (optimistic concurrency).
- Understand deadlocks: acquire locks in a consistent order; keep transactions small; retry on
  deadlock errors.

### BASE (many NoSQL stores)
**B**asically **A**vailable, **S**oft state, **E**ventually consistent — trades strong consistency
for availability and scale (see CAP in [scaling-and-performance.md](./scaling-and-performance.md)).
Choose BASE only where the data tolerates staleness.

---

## Step 6 — Scaling the Data Layer

Databases are usually the first bottleneck. Techniques, roughly in order of when to reach for them:

| Technique | What it does | Cost / caveat |
|-----------|--------------|---------------|
| **Indexing & query tuning** | Fix the actual slow queries first | Cheapest, biggest early win |
| **Connection pooling** | Reuse DB connections (PgBouncer, HikariCP) | Essential; connections are scarce |
| **Caching** | Absorb hot reads before they hit the DB | Invalidation complexity → [caching.md](./caching.md) |
| **Read replicas** | Route reads to replicas, writes to primary | **Replication lag** → stale reads |
| **Vertical scaling** | Bigger box | Simple but has a ceiling and a bill |
| **Federation** | Split DBs by function (users / orders / catalog) | App must route; cross-DB joins hard |
| **Sharding / partitioning** | Split one dataset across nodes by a shard key | Cross-shard queries & rebalancing are hard |
| **Denormalization / materialized views** | Precompute expensive reads | Duplicate data; keep it in sync |

### Replication
- **Primary-replica** (master-slave): primary takes writes, replicas serve reads. Add logic/tooling
  to promote a replica on failover. Watch **replication lag** — a user may not read-their-own-write
  from a replica; route such reads to the primary.
- **Multi-primary** (master-master): multiple write nodes; introduces write-conflict resolution and
  usually loosens consistency. Use only when you truly need multi-region writes.

### Sharding (partitioning across nodes)
- **Shard key** choice is everything. Good keys spread load evenly and keep related data together.
- Strategies: **hash** (even spread, hard range scans), **range** (range scans easy, risk hotspots),
  **directory/lookup** (flexible, extra hop), **geo** (data locality).
- **Consistent hashing** minimizes data movement when adding/removing nodes.
- Costs: cross-shard joins/transactions are hard; **hot shards** (a celebrity user) skew load;
  rebalancing is operationally painful. Shard late, and only when a single node truly can't cope.

### Partitioning (within one DB)
Table partitioning (by range/date, list, or hash) keeps big tables manageable and lets you drop
old partitions cheaply — great for time-series/log data.

---

## Step 7 — Migrations & Evolution

Schema change is a deployment risk. Use **backward-compatible, multi-step** changes:

```
EXPAND  → add the new column/table (nullable/defaulted), deploy code that writes both
MIGRATE → backfill existing rows in batches (avoid one giant locking update)
CONTRACT→ switch reads to the new shape, then drop the old column in a later deploy
```
- Never deploy a destructive change (`DROP`/`RENAME`) in the same release as the code that stops
  using it — old instances are still running during a rolling deploy.
- Use a migration tool with version history (Flyway, Liquibase, Alembic, Prisma Migrate, EF Core
  Migrations, ActiveRecord, golang-migrate). Migrations live in version control and run in CI/CD.
- Test migrations on production-like data volume; a backfill that's instant on 1k rows can lock a
  table for minutes on 100M rows.

---

## Red Flags (grep for these)

```bash
# Money stored as float/double  → rounding errors
grep -rEn "FLOAT|DOUBLE|REAL" --include=*.sql .
# String-concatenated SQL       → injection + no plan caching
grep -rEn "\"SELECT .*\" ?\+|f\"SELECT|\$\{.*\}.*FROM" .
# N+1: query inside a loop
grep -rEn "for .*\{[^}]*(query|find|SELECT)" .
# SELECT *  in hot paths        → fetches unused columns, breaks covering indexes
grep -rEn "SELECT \*" .
# Missing WHERE on UPDATE/DELETE → mass mutation
grep -rEn "(UPDATE|DELETE) FROM? [a-z_]+;?$" .
```

---

## Anti-Patterns

- ❌ **Choosing NoSQL to avoid schema design** — you still model data; you just do it in app code, worse.
- ❌ **Floats for money** — use decimal/integer-cents.
- ❌ **Sharding too early** — enormous complexity before a single node is even stressed.
- ❌ **Unbounded arrays / ever-growing documents** — model as a child collection instead.
- ❌ **No `EXPLAIN`** — guessing at indexes instead of reading the query plan.
- ❌ **Long transactions with IO inside** — holding locks across network calls.
- ❌ **Destructive migration in one step** — breaks rolling deploys and has no rollback.
- ❌ **Reading your own writes from a lagging replica** — route those reads to the primary.
