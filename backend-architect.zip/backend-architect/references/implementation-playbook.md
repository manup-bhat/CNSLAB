# Implementation Playbook (BUILD)

A tech-agnostic, end-to-end recipe for building a production-ready backend service or feature — and
for safely extending an existing one. Each step states *what* and *why*; the *how* per language is
in [tech-stack-guide.md](./tech-stack-guide.md).

> **Rule**: Production-ready by construction, not retrofit. Validation, error handling, config,
> logging, and tests are written *with* the feature, not bolted on before launch.

---

## Greenfield: Build a Service/Feature End-to-End

Follow the checkpoints in order. Don't skip ahead — each unlocks the next.

### 1. Scaffold the project structure (by feature, then layer)
```
src/
  orders/                 # feature module (bounded context)
    domain/               # entities, value objects, domain services  (no framework/IO)
    application/          # use-case services, command/query handlers
    infrastructure/       # repositories, external clients, adapters
    api/                  # controllers/routers, request/response DTOs
  shared/                 # cross-cutting: config, logging, errors, middleware
  main.*                  # composition root: wire dependencies, start server
tests/
```
✅ **Checkpoint**: a new engineer can guess where any file goes. Domain has no framework imports.

### 2. Externalize configuration (12-Factor)
- Read all config from **environment variables** (with a typed, validated config object).
- **Never** hardcode URLs, credentials, or keys. Secrets come from a vault/secret manager.
- Fail fast at startup if required config is missing or invalid.

✅ **Checkpoint**: the same build artifact runs in dev/stage/prod with only env changes; no secret
is in source control.

### 3. Build the data-access layer
- Define repository interfaces in the domain; implement them in infrastructure.
- Use parameterized queries / an ORM — **never** string-concatenate SQL.
- Manage connections with a **pool**; set sane pool size, timeouts, and statement timeouts.
- Add migrations (versioned, backward-compatible). → [data-modeling-and-databases.md](./data-modeling-and-databases.md)

✅ **Checkpoint**: you can save and load an aggregate; no raw SQL interpolation; pool configured.

### 4. Build the API/transport layer
- Map routes to thin controllers that **delegate to application services** (no business logic here).
- Define explicit **request/response DTOs** — never expose ORM entities directly (prevents mass
  assignment / over-exposure; OWASP API3).
- Consistent response envelope and status codes. → [api-design.md](./api-design.md)

✅ **Checkpoint**: controllers are thin; internal models aren't leaked to clients.

### 5. Validate all input at the boundary
- Validate type, format, range, length, and allowed values of **every** external input (body,
  query, params, headers) before it reaches business logic.
- Reject unknown fields; whitelist sortable/filterable fields. Treat all client data as hostile.

✅ **Checkpoint**: malformed/oversized/unexpected input returns 400/422, never a 500 or a crash.

### 6. Add authentication & authorization
- AuthN: verify identity (session/JWT/OAuth2) in middleware.
- **AuthZ on every protected action**: check the caller may act on *this specific object*
  (object-level, prevents BOLA) and *this function* (function-level, prevents BFLA). Never trust a
  client-supplied user/tenant id. → [security.md](./security.md)

✅ **Checkpoint**: accessing another user's resource by changing an id returns 403/404, not data.

### 7. Handle errors consistently
- Distinguish domain errors (→ 4xx) from faults (→ 5xx). A **global error handler** catches
  unhandled errors, logs them with the correlation id, and returns a safe RFC 9457 problem
  response — no stack traces or internals to clients.
- Don't swallow exceptions; wrap with context when rethrowing. → [low-level-design.md](./low-level-design.md)

✅ **Checkpoint**: every error path returns a clean, typed response; failures are logged with context.

### 8. Add structured logging & correlation
- **Structured** (JSON) logs, not `print`. Attach a **correlation/request id** to every log line;
  generate it at the edge and propagate it through calls and messages.
- Log at boundaries (request in/out, external calls, key domain events). **Never log secrets/PII.**
  → [production-readiness.md](./production-readiness.md)

✅ **Checkpoint**: you can trace one request across all its log lines by its correlation id.

### 9. Write the tests (alongside, not after)
- Unit-test the domain (pure, fast, no IO). Integration-test the data/API layers (real DB via
  testcontainers). Contract-test service boundaries. → [testing-strategy.md](./testing-strategy.md)

✅ **Checkpoint**: critical paths are covered; tests run in CI and gate merges.

### 10. Make it observable & resilient
- Health endpoints (liveness/readiness), metrics (RED), tracing.
- Timeouts on every outbound call; retries with backoff+jitter; circuit breakers on flaky deps.
  → [production-readiness.md](./production-readiness.md), [scaling-and-performance.md](./scaling-and-performance.md)

✅ **Checkpoint**: the service reports health, emits metrics/traces, and degrades gracefully.

### 11. Containerize & wire CI/CD
- Minimal, multi-stage image; run as non-root; pin base image; `.dockerignore` secrets.
- CI: lint → typecheck → test → security scan → build → deploy (with migrations run safely).
  → [production-readiness.md](./production-readiness.md)

✅ **Checkpoint**: one command builds a reproducible image; the pipeline blocks bad merges.

---

## Brownfield: Safely Extend an Existing Service

```
1. UNDERSTAND  Map the area you're touching: entry point → service → data → downstream.
               Read the code and existing tests before editing. → requirements-and-estimation (discovery)
2. CHARACTERIZE Add tests that capture current behavior if none exist (a safety net for refactor).
3. SMALLEST CHANGE  Implement behind the existing seams; match local conventions and patterns.
4. PRESERVE CONTRACTS  Keep the public API/event schema backward compatible (additive only).
5. MIGRATE DATA SAFELY  Expand → backfill → contract; never destructive in one deploy.
6. TEST  Add/extend unit + integration tests for the change; keep the characterization tests green.
7. OBSERVE  Add logs/metrics for the new path; roll out behind a flag if risky.
```
> Match the codebase's existing style and abstractions. Don't introduce a new framework, pattern,
> or dependency for one feature unless it clearly pays for itself.

---

## Cross-Cutting Concerns Checklist (applies to every build)

| Concern | Do |
|---------|-----|
| **Config** | Env-based, validated at startup, secrets in a vault |
| **Input validation** | At the boundary, whitelist, reject unknowns |
| **AuthN/Z** | Middleware authn; per-object + per-function authz |
| **Errors** | Global handler, RFC 9457, no internals leaked |
| **Logging** | Structured, correlation id, no secrets/PII |
| **Transactions** | Short; one aggregate per transaction; no IO inside |
| **Idempotency** | Idempotency keys for unsafe retryable writes |
| **Timeouts/retries** | On every outbound call |
| **Tests** | Written with the code; run in CI |
| **Migrations** | Versioned, backward-compatible, tested at scale |

---

## Definition of Done (a feature is not "done" until…)

- [ ] Functional requirement met and demoed on a realistic case.
- [ ] Input validated; happy path **and** error paths handled.
- [ ] AuthN/AuthZ enforced (including object-level).
- [ ] Structured logs + metrics + correlation id in place.
- [ ] Tests (unit + integration for critical paths) green in CI.
- [ ] No secrets in code; config externalized.
- [ ] Backward-compatible API/schema/migration.
- [ ] Runs in a container; pipeline green; observability wired.
- [ ] Ship checklist reviewed. → [checklist.md](./checklist.md)

---

## Anti-Patterns

- ❌ **Business logic in controllers** — the transport layer computing rules instead of delegating.
- ❌ **Exposing ORM entities** as API responses/requests — leaks fields, invites mass assignment.
- ❌ **"Add tests later"** — later never comes; the code becomes untestable.
- ❌ **Security/observability last** — retrofitting is far more expensive and error-prone.
- ❌ **Big-bang brownfield edits** — refactoring an unfamiliar module with no characterization tests.
- ❌ **New dependency per feature** — dependency sprawl and supply-chain risk for marginal benefit.
- ❌ **Swallowing errors to "make it work"** — hiding failures that resurface in production.
