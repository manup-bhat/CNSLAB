# Low-Level Design (LLD) — The Shape of the Code

While HLD decides how the system is split into services, LLD decides how the **code inside** a
service/module is structured so it stays correct, testable, and changeable. This reference covers
DDD tactical patterns, SOLID, layering (clean/hexagonal), design patterns useful in backends,
error modeling, and concurrency.

> **Rule**: Business logic should not depend on frameworks, databases, or transport. Keep the
> domain at the center; make everything else a replaceable detail at the edge.

---

## Layering — Keep Dependencies Pointing Inward

Most maintainable backends use a layered/clean/hexagonal structure:

```
        ┌─────────────────────────────────────────────┐
        │  Transport / API layer                        │  HTTP, gRPC, CLI, message consumers
        │  (controllers, routers, handlers, DTOs)       │  — maps external ⇄ internal
        ├─────────────────────────────────────────────┤
        │  Application / Service layer                  │  use cases, orchestration,
        │  (use-case services, command handlers)        │  transactions — no business rules here
        ├─────────────────────────────────────────────┤
        │  Domain layer  ★ the core                     │  entities, value objects, aggregates,
        │  (business rules, invariants)                 │  domain services — no framework/IO
        ├─────────────────────────────────────────────┤
        │  Infrastructure layer                         │  DB repos, HTTP clients, brokers,
        │  (adapters implementing domain ports)         │  cache — the replaceable details
        └─────────────────────────────────────────────┘
        Dependency rule: outer layers depend on inner; the domain depends on NOTHING external.
```

**Hexagonal (Ports & Adapters)**: the domain defines **ports** (interfaces like
`OrderRepository`, `PaymentGateway`); infrastructure provides **adapters** (Postgres repo, Stripe
client). The domain is testable in isolation with fakes, and you can swap Postgres for another
store without touching business rules.

**Why it matters**: frameworks and databases change; business rules are your durable asset.
Isolating them keeps tests fast (no DB needed for domain tests) and change cheap.

---

## Domain-Driven Design — Tactical Patterns

| Building block | Definition | Example |
|----------------|-----------|---------|
| **Entity** | Has identity that persists over time | `User(id)`, `Order(id)` |
| **Value object** | Defined by attributes, immutable, no identity | `Money(amount, currency)`, `Email`, `DateRange` |
| **Aggregate** | Cluster of entities/VOs with one **root** and a consistency boundary | `Order` (root) + `OrderLine`s |
| **Aggregate root** | The only entry point; enforces the aggregate's invariants | `order.addLine(...)` validates totals |
| **Repository** | Collection-like interface to load/save aggregates | `orderRepo.save(order)` |
| **Domain service** | Business logic that doesn't belong to one entity | `PricingService`, `TransferService` |
| **Domain event** | Something meaningful happened | `OrderPlaced`, `PaymentFailed` |
| **Factory** | Encapsulates complex creation with invariants | `Order.create(...)` |

**Aggregate rules**: keep aggregates **small**; reference other aggregates **by id**, not by object;
one transaction should modify **one aggregate**; enforce all invariants inside the root. These
rules are exactly what make it possible to later split by aggregate into services.

**Ubiquitous language**: name code after the business's own words. If the business says "invoice",
don't call it `BillingRecord`. Shared language prevents translation bugs.

---

## SOLID — The Five Principles

| Principle | Rule | Backend smell when violated |
|-----------|------|------------------------------|
| **S**ingle Responsibility | One reason to change per class/module | A `UserService` doing auth + email + billing + reporting |
| **O**pen/Closed | Open to extension, closed to modification | A `switch(type)` edited for every new payment method |
| **L**iskov Substitution | Subtypes usable wherever the base is | A `ReadOnlyRepo` subtype that throws on `save()` |
| **I**nterface Segregation | Small, focused interfaces | A fat `IRepository` with 30 methods; clients use 3 |
| **D**ependency Inversion | Depend on abstractions, not concretions | Domain code doing `new PostgresClient()` |

**Dependency Inversion in practice = Dependency Injection**: pass collaborators in (constructor
injection) rather than constructing them inside. This is what lets you test with fakes and swap
adapters. Most backend frameworks provide a DI container (Spring, NestJS, ASP.NET Core, FastAPI's
`Depends`), but constructor injection works everywhere without one.

---

## Design Patterns Useful in Backends

| Pattern | Backend use |
|---------|-------------|
| **Repository** | Abstract data access behind a domain-friendly interface |
| **Unit of Work** | Group repository changes into one transaction/commit |
| **Strategy** | Swap algorithms (pricing rules, retry policy) without `if/else` forests |
| **Factory / Builder** | Construct complex/valid objects (aggregates, config) |
| **Adapter** | Wrap a third-party/legacy API to fit your interface (also an ACL) |
| **Decorator** | Layer cross-cutting behavior (caching, logging, retry) around a component |
| **Observer / Pub-Sub** | Emit domain events for other parts to react to |
| **Chain of Responsibility** | Middleware/interceptor pipelines (auth → validate → handle) |
| **Command** | Represent an operation as an object (great for CQRS write side, queues) |
| **Circuit Breaker** | Wrap remote calls for resilience (see production-readiness) |

Use a pattern because it removes real duplication or coupling — not to show you know it. A pattern
applied to a problem you don't have is just complexity.

---

## Modeling Errors Explicitly

Errors are part of the design, not an afterthought.

- **Distinguish** expected domain errors (validation failed, insufficient funds, not found) from
  unexpected faults (DB down, bug). Handle the former as normal control flow; let the latter bubble
  to a global handler that logs and returns a safe 5xx.
- **Don't swallow exceptions** — an empty `catch {}` hides bugs. Handle, wrap with context, or
  rethrow.
- **Carry context**: attach the operation, ids, and cause when wrapping (`throw new
  OrderError("charge failed", { orderId, cause })`). Never leak stack traces/secrets to clients.
- **Result vs exceptions**: Go returns `error` values; Rust uses `Result`; others use exceptions.
  Whatever the language, make the failure path explicit and typed where possible.
- **Fail fast at the boundary**: validate input at the transport layer; the domain should be able
  to assume valid inputs.

```
API layer:      validate DTO → map to command → call use case → map result/errors to HTTP status
Domain layer:   assume valid input; throw/return typed domain errors on business rule violations
Global handler: catch unhandled → log with correlation id → return RFC 9457 problem+json (no internals)
```

---

## Concurrency Models

Pick the model your runtime gives you and respect its rules:

| Model | Runtimes | Watch for |
|-------|----------|-----------|
| **Thread-per-request + pools** | Java, .NET, Go (goroutines are cheap) | Shared mutable state → locks; thread-pool exhaustion |
| **Async/await event loop** | Node.js, Python asyncio, .NET async | **Never block the loop** with sync CPU/IO; forgotten `await` |
| **Actors / message passing** | Erlang/Elixir, Akka | Mailbox backpressure; ordering |
| **Goroutines + channels** | Go | Goroutine leaks; unbuffered-channel deadlocks |

Universal concurrency hazards (see [bug-detection-and-fixing.md](./bug-detection-and-fixing.md)):
- **Race conditions**: shared mutable state without synchronization → guard with locks, atomics, or
  by not sharing (per-request state, immutability).
- **Deadlocks**: acquire locks in a consistent global order; keep critical sections tiny.
- **Read-modify-write races** on data: use DB-level locking or optimistic concurrency (version
  column), not app-level "check then act".
- **Idempotency**: make operations safe to run twice (concurrency + retries will run them twice).

---

## Function & Module Hygiene

- **Small functions**, one level of abstraction each; a function you can't grasp in ~30 seconds is
  too big or too clever.
- **Cognitive complexity** low: few nested branches; prefer early returns/guard clauses over deep
  `if` nesting.
- **Pure core, effects at the edge**: push IO to the boundaries; keep decision logic pure and
  trivially testable.
- **Name for intent**, not implementation (`chargeOverdueInvoices()` not `runJob2()`).
- **No god objects/modules**: a class > ~300 lines or with > ~5 responsibilities is a refactor
  signal.

---

## Anti-Patterns

- ❌ **Anemic domain model** — entities are just bags of getters/setters; all logic sits in fat
  "services" (procedural code wearing OO clothes). Put behavior with the data it guards.
- ❌ **Framework in the core** — importing HTTP/ORM types into domain logic; now you can't test or
  swap them.
- ❌ **Business logic in controllers** — the transport layer computing prices/rules instead of
  delegating to the domain.
- ❌ **Swallowed exceptions** — `catch (e) {}` that hides failures.
- ❌ **Primitive obsession** — passing raw strings/ints for `Email`, `Money`, `UserId` instead of
  value objects; invites mix-ups and missing validation.
- ❌ **Pattern-itis** — factories of factories, needless abstractions with one implementer (YAGNI).
- ❌ **Shared mutable state** across requests/threads without synchronization.
- ❌ **Huge aggregates** — loading half the database to change one field; kills concurrency and speed.
