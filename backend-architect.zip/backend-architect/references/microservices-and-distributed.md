# Microservices & Distributed Systems (HLD)

Once a system is distributed, everything gets harder: data spans services, the network is
unreliable, and consistency is no longer free. This reference is the pattern catalog for building
distributed backends that actually work — decomposition, data management, communication,
reliability, and the distributed-data patterns (Saga, CQRS, event sourcing, outbox).

> **Rule**: In a distributed system, assume every remote call can be slow, fail, or be duplicated.
> Design for partial failure and idempotency from the start — they are not add-ons.

---

## Decomposition — Finding Service Boundaries

Bad boundaries are the #1 cause of microservice pain. Decompose by the **business**, not by
technical layers.

| Strategy | How | Result |
|----------|-----|--------|
| **By business capability** | One service per capability (Orders, Payments, Inventory) | Aligns with how the business works |
| **By subdomain (DDD)** | Identify bounded contexts; a service per context | Strong cohesion, clear ownership |
| **Self-contained service** | Service handles requests without synchronous calls to others | Fewer cascading failures |
| **Service per team** | Conway's Law: align services to team ownership | Autonomy, faster delivery |

Signals of a **good** boundary: high internal cohesion, loose coupling, changes usually stay inside
one service, and it owns its data. Signals of a **bad** boundary: two services always change and
deploy together, or one can't function without synchronously calling the other — merge them.

---

## Data Management — The Hard Part

### Database per Service
Each service owns its data privately; no other service touches its tables. This is what makes
services independently deployable and scalable. The consequence: **you can no longer JOIN across
services or use one ACID transaction** across them. The patterns below solve that.

### Querying across services
| Pattern | Use when | How |
|---------|----------|-----|
| **API Composition** | Simple joins, low volume | Query each owning service, join in memory |
| **CQRS** | Complex queries, high read volume | Maintain a read-optimized materialized view fed by events |

### CQRS (Command Query Responsibility Segregation)
Separate the **write model** (commands, normalized, enforces invariants) from one or more **read
models** (queries, denormalized, shaped per view). Read models are updated asynchronously from
events. Use it where read and write needs diverge sharply or reads vastly outnumber writes. Cost:
eventual consistency between write and read side, and more moving parts. Don't apply CQRS to simple
CRUD.

### Event Sourcing
Persist state as an **append-only log of events** (`OrderPlaced`, `OrderPaid`, `OrderShipped`)
instead of just current state. Rebuild state by replaying events; get a full audit trail and
time-travel for free. Often paired with CQRS (events feed read models). Costs: schema evolution of
events, replay performance (mitigated by **snapshots**), and a steep learning curve. Use it where
audit/history/replay is a real requirement — not everywhere.

---

## Distributed Transactions — Saga

You cannot hold an ACID transaction across services. A **Saga** is a sequence of local transactions
where each step publishes an event/command that triggers the next; if a step fails, **compensating
transactions** undo the previous steps.

| Coordination | How | Trade-off |
|--------------|-----|-----------|
| **Choreography** | Each service reacts to events, no central coordinator | Loose coupling; flow is implicit and harder to see |
| **Orchestration** | A central orchestrator tells each service what to do | Explicit, visible flow; orchestrator is a dependency |

```
Order Saga (orchestrated):
  1. Order service:     create order (PENDING)      → cmd: reserve stock
  2. Inventory service: reserve stock               → cmd: take payment
  3. Payment service:   charge card                 → event: paid
     └─ on failure:     Inventory.release + Order.cancel   (compensations)
  4. Order service:     mark CONFIRMED
```
Design compensations up front for every step. Sagas give **eventual** consistency, not atomicity —
the UI/domain must tolerate the in-between states.

---

## Reliable Messaging — The Outbox Pattern

Problem: a service must update its DB **and** publish an event. Doing both non-atomically means a
crash between them loses the event (or publishes one for a rolled-back change) — the **dual-write
problem**.

**Transactional Outbox**: within the same DB transaction that changes state, insert the event into
an `outbox` table. A separate relay process reads the outbox and publishes to the broker, marking
rows sent. State change and event are now atomic (same transaction).

```
BEGIN;
  UPDATE orders SET status='PAID' WHERE id=$1;
  INSERT INTO outbox(aggregate_id, type, payload) VALUES ($1, 'OrderPaid', $2);
COMMIT;
-- Relay: poll outbox (Polling Publisher) or tail the DB log (Transaction Log Tailing/CDC) → broker
```
Consumers must be **idempotent** (the relay guarantees at-least-once, so duplicates happen).
→ [realtime-and-messaging.md](./realtime-and-messaging.md)

---

## Communication Between Services

| Style | Mechanism | Use when |
|-------|-----------|----------|
| **Sync request/response** | REST, gRPC | Client needs an immediate answer; simple queries |
| **Async messaging** | Queue/broker events | Decoupling, resilience, spiky load, workflows |

- Prefer **async** for inter-service communication where possible — it decouples lifecycles and
  survives downstream outages (messages wait in the queue). Sync chains couple availability
  (each hop multiplies failure probability) and add latency.
- **gRPC** for high-throughput internal calls (binary Protobuf, HTTP/2, streaming, codegen).
- **Idempotent Consumer**: consumers must handle the same message arriving more than once
  (dedupe by message id / use idempotency keys).
- **API Gateway / BFF**: a single entry point for external clients that routes to services, handles
  cross-cutting concerns (auth, rate limiting, TLS), and aggregates. A **Backend-for-Frontend** is
  a gateway tailored to one client type (web vs mobile) to avoid a one-size-fits-none API.

---

## Service Discovery

Service instances come and go (autoscaling, restarts), so their locations are dynamic.
- **Service registry** (Consul, etcd, Eureka): a database of live instance locations, kept fresh by
  **health checks** and self-/third-party registration.
- **Client-side discovery**: client queries the registry and load-balances itself.
- **Server-side discovery**: a load balancer/router queries the registry (common with Kubernetes
  Services + kube-proxy, or a service mesh).

---

## Reliability — Design for Partial Failure

A failure in one service must not cascade into a system-wide outage.

| Pattern | Purpose |
|---------|---------|
| **Timeout** | Never wait forever on a remote call — bound every one |
| **Retry (backoff + jitter)** | Recover from transient blips; jitter avoids retry storms; only retry idempotent ops |
| **Circuit breaker** | After N failures, "open" and fail fast for a cooldown, giving the dependency time to recover |
| **Bulkhead** | Isolate resources (thread/connection pools) per dependency so one slow dep can't drain them all |
| **Fallback / graceful degradation** | Serve cached/default/partial data when a dependency is down |
| **Rate limiting / load shedding** | Reject excess load with 429 instead of collapsing |

See implementation details and knobs in [production-readiness.md](./production-readiness.md).

---

## Cross-Cutting Concerns

- **Externalized configuration** — config and secrets come from the environment/vault, not the image.
- **Microservice chassis / service template** — a shared starter that bakes in logging, metrics,
  tracing, health checks, config, and resilience so every new service is consistent.
- **Sidecar / service mesh** (Istio, Linkerd): move cross-cutting networking concerns (mTLS,
  retries, tracing, traffic shifting) into a proxy alongside each service, out of app code.

---

## Observability in Distributed Systems (non-negotiable)

You cannot debug what you cannot see across a call graph.
- **Correlation/trace ID** propagated through every hop (inject at the gateway, pass in headers/
  message metadata).
- **Distributed tracing** (OpenTelemetry → Jaeger/Tempo/Zipkin) to see a request across services.
- **Centralized log aggregation** and **per-service metrics** + **health check APIs**.
→ [production-readiness.md](./production-readiness.md)

---

## When NOT to Use Microservices

- Small team / early product / unclear domain → modular monolith.
- Strong consistency needed across most of the domain → one database is far simpler.
- No CI/CD, no tracing, no container platform → build that maturity first.
- The domain doesn't decompose into loosely-coupled contexts → forcing it creates a distributed
  monolith.

---

## Anti-Patterns

- ❌ **Shared database** between services — the classic distributed monolith.
- ❌ **Synchronous call chains** — A→B→C→D where any hop's latency/failure sinks the request.
- ❌ **Dual writes** — updating the DB and publishing an event without the outbox pattern.
- ❌ **Non-idempotent consumers** — assuming exactly-once delivery (it doesn't exist end-to-end).
- ❌ **No compensations** — a Saga with no plan for undoing partial work.
- ❌ **Distributed transactions (2PC)** across services — brittle, slow, availability-killing.
- ❌ **No distributed tracing** — debugging a cross-service issue by grepping seven log files by hand.
- ❌ **Chatty services** — dozens of fine-grained calls where one coarse call (or an event) would do.
