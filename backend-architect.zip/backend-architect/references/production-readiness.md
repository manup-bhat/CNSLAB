# Production Readiness (HARDEN)

Working code is not production-ready code. This reference covers what turns a service into one you
can operate, observe, and trust under real conditions: 12-Factor hygiene, observability, health &
lifecycle, resilience patterns, and safe delivery.

> **Rule**: If you can't observe it, you can't operate it. Logs, metrics, traces, and health
> checks are part of the feature — not a follow-up ticket.

---

## The 12-Factor App (cloud-native baseline)

| Factor | Do |
|--------|-----|
| **Codebase** | One repo per app, many deploys |
| **Dependencies** | Declare explicitly; lockfile; no reliance on system-wide packages |
| **Config** | In the **environment**, not code; secrets in a vault |
| **Backing services** | DB/cache/queue are attached resources swappable by config |
| **Build, release, run** | Strict separation; immutable releases; no editing running instances |
| **Processes** | **Stateless**; share nothing; persist state in backing services |
| **Port binding** | Self-contained; export via a port |
| **Concurrency** | Scale out via the process model |
| **Disposability** | Fast startup, **graceful shutdown**; robust to sudden death |
| **Dev/prod parity** | Keep environments as similar as possible |
| **Logs** | Treat as **event streams** to stdout; don't manage log files |
| **Admin processes** | Run migrations/one-offs as one-off processes |

---

## Observability — Logs, Metrics, Traces

The three pillars. Instrument from day one; retrofitting during an incident is too late.

### Structured logging
- Emit **JSON** (or key-value) logs to stdout; ship centrally (ELK/Loki/Datadog/CloudWatch).
- Attach a **correlation/request id** to every line; propagate it across services & messages.
- Levels: ERROR (needs attention), WARN (suspicious), INFO (key events), DEBUG (dev only).
- **Never log secrets, tokens, passwords, or full PII.** Redact/mask.

### Metrics
- **RED** (for request-driven services): **R**ate, **E**rrors, **D**uration (latency percentiles).
- **USE** (for resources): **U**tilization, **S**aturation, **E**rrors.
- Track the **golden signals**: latency, traffic, errors, saturation.
- Use histograms for latency (so you get true p95/p99), counters for events, gauges for levels.
- Export to Prometheus/OpenTelemetry; build dashboards and **alerts tied to SLOs/error budgets**.

### Distributed tracing
- Propagate trace context (W3C `traceparent`) across every hop; one trace = one request's journey.
- **OpenTelemetry** is the vendor-neutral standard (→ Jaeger/Tempo/Zipkin/vendors).
- Essential for microservices — you cannot debug a cross-service latency spike without it.
  → [microservices-and-distributed.md](./microservices-and-distributed.md)

---

## Health Checks & Lifecycle

| Probe | Answers | Action if failing |
|-------|---------|-------------------|
| **Liveness** | "Is the process healthy (not deadlocked)?" | Restart the instance |
| **Readiness** | "Can it serve traffic (deps up, warmed)?" | Remove from the load balancer until ready |
| **Startup** | "Has a slow-starting app finished booting?" | Delay liveness checks during boot |

- Readiness should check critical dependencies (DB, cache) — but avoid cascading failure (don't
  mark unready for a non-critical dependency).
- **Graceful shutdown**: on SIGTERM, stop accepting new work, finish in-flight requests within a
  timeout, drain connections, flush logs/metrics, then exit. Critical for zero-downtime rolling
  deploys and autoscaling.

```
SIGTERM → stop LB traffic (fail readiness) → finish in-flight (with deadline) → close DB/pools →
flush telemetry → exit 0
```

---

## Resilience Patterns (from Release It!)

Design for partial failure; a dependency **will** be slow or down.

| Pattern | Purpose | Knobs |
|---------|---------|-------|
| **Timeout** | Never wait forever on a remote call | Per-call deadline; propagate a request budget |
| **Retry** | Recover transient failures | Exponential backoff **+ jitter**; cap attempts; only for **idempotent** ops |
| **Circuit breaker** | Stop hammering a failing dependency | Open after N failures; half-open probe; fail fast while open |
| **Bulkhead** | Isolate resource pools per dependency | Separate thread/connection pools so one dep can't drain all |
| **Fallback / degrade** | Serve reduced function when a dep is down | Cached/default/partial responses |
| **Load shedding** | Protect the core under overload | Reject low-priority work with 429/503 |
| **Idempotency** | Make retries safe | Idempotency keys; dedupe |

> Retries without backoff+jitter cause **retry storms** that turn a blip into an outage. Retries on
> non-idempotent operations cause **duplicates** (double charges). Combine retry + circuit breaker +
> timeout — they work together.

---

## Configuration & Secrets in Production

- All config from env/config service; **validate at startup** and fail fast on missing/invalid.
- Secrets from a manager (Vault/cloud), never baked into images or logs. Rotate regularly.
- **Feature flags** for decoupling deploy from release, gradual rollout, and kill switches.
- Keep environments at parity; differences should be config, not code.

---

## Delivery: CI/CD & Deployment

- **CI pipeline gate**: lint → typecheck → unit+integration tests → dependency/security scan →
  build image → (optional) e2e. Block merges on failure.
- **Immutable artifacts**: build once, promote the same image dev→stage→prod.
- **Migrations** run as a controlled step, backward-compatible (expand→migrate→contract), so old and
  new code can run together during rollout. → [data-modeling-and-databases.md](./data-modeling-and-databases.md)
- **Deploy strategies**: rolling (default), blue-green (instant switch/rollback), canary (small %
  first, watch metrics, then ramp). All require health checks + graceful shutdown to be zero-downtime.
- **Rollback plan** for every deploy; practice it.

---

## Containers & Runtime Hygiene

- Multi-stage builds → small images; pin base image digests; `.dockerignore` secrets/junk.
- Run as **non-root**; read-only filesystem where possible; drop capabilities.
- Set resource **requests/limits**; a container without limits can starve its neighbors.
- Externalize all state; the container is disposable.

---

## Reliability & Data Safety

- **Backups**: automated, **tested** restores (an untested backup is a hope, not a backup). Define
  **RPO** (max data loss) and **RTO** (max downtime).
- **Disaster recovery**: know how to restore/failover; document and rehearse the runbook.
- **Multi-AZ** for high availability; multi-region only when the requirement (and budget) justifies.
- **Idempotent, resumable** jobs so a crash mid-batch doesn't corrupt or duplicate.

---

## Cost Awareness

Production readiness includes not going bankrupt: right-size instances, scale-to-zero where it fits,
set budgets/alerts, watch egress and per-request third-party costs, and cache to cut compute/DB load.
Efficiency is a feature.

---

## Production-Readiness Gate (before first real traffic)

- [ ] Structured logs + correlation id; no secrets/PII logged.
- [ ] Metrics (RED/USE) + dashboards + SLO-based alerts.
- [ ] Distributed tracing across services.
- [ ] Liveness/readiness probes; graceful shutdown on SIGTERM.
- [ ] Timeouts + retries(+jitter) + circuit breakers on all outbound calls.
- [ ] Config in env; secrets in a vault; validated at startup.
- [ ] Rate limiting / load shedding in place.
- [ ] CI gates (tests + security scan); immutable image; runs as non-root.
- [ ] Safe migration path; deploy + rollback strategy.
- [ ] Backups with tested restore; RPO/RTO defined.
→ Full list in [checklist.md](./checklist.md)

---

## Anti-Patterns

- ❌ **`console.log`/`print` debugging in prod** — unstructured, no context, no correlation.
- ❌ **No health checks / no graceful shutdown** — deploys drop live requests.
- ❌ **Retries without backoff/jitter** — retry storms amplify outages.
- ❌ **No timeouts on remote calls** — one slow dependency hangs every request thread.
- ❌ **Config/secrets baked into images** — leaks and no per-env flexibility.
- ❌ **Alerting on everything** — alert fatigue; alert on SLO burn and symptoms, not every metric.
- ❌ **Untested backups** — discovering the restore is broken during an incident.
- ❌ **Averaged latency dashboards** — hide the p99 pain real users feel.
- ❌ **Deploy = release with no flags/canary** — every release is all-or-nothing risk.
