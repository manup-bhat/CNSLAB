# Real-Time & Messaging (COMMS)

Not everything is request/response. This reference covers pushing data to clients (WebSockets, SSE,
webhooks) and decoupling services with asynchronous messaging (pub/sub, queues, event streaming),
including the delivery guarantees and failure modes that trip people up.

> **Rule**: Asynchronous messaging buys you decoupling and resilience at the price of eventual
> consistency and duplicate/out-of-order delivery. Design **idempotent consumers** and dead-letter
> handling from the start — they are not optional.

---

## Real-Time: Pushing to Clients

| Tech | Direction | Use for | Notes |
|------|-----------|---------|-------|
| **Polling** | client pulls | Simple, low-freq updates | Wasteful; latency = poll interval |
| **Long-polling** | client pulls, server holds | Fallback where WS unavailable | Ties up connections |
| **SSE** (Server-Sent Events) | server → client (one-way) | Live feeds, notifications, progress, tokens (LLM streaming) | Auto-reconnect, over plain HTTP, text only |
| **WebSocket** | bidirectional | Chat, collaboration, games, live dashboards | Persistent TCP; needs its own scaling/auth story |
| **Webhook** | server → server | Third-party event delivery (Stripe, GitHub) | You are the receiver; verify signatures, ack fast |

### WebSockets — what to get right
- **Auth**: authenticate at the handshake (token in the initial request); you can't rely on cookies
  across origins. Re-check authz for actions over the socket.
- **Scaling**: sockets are **stateful** — a client is pinned to one server. To broadcast across a
  cluster, use a **backplane** (Redis pub/sub, or a hosted service) so any node can reach any client.
  Track connections in a shared store, not process memory.
- **Backpressure & limits**: cap message size and rate per connection; drop/slow clients that can't
  keep up; heartbeat/ping-pong to detect dead connections; clean up on disconnect (avoid leaks).
- **Reconnection**: clients drop constantly (mobile networks). Support resume/replay (last-event-id)
  where correctness needs it.

### SSE — the underrated choice
For **server→client only** streams (notifications, progress bars, streaming LLM tokens), SSE is
simpler than WebSockets: plain HTTP, automatic reconnection, works through most proxies. Choose it
whenever you don't need client→server over the same channel.

### Webhooks — when you're the receiver
- **Verify the signature** (HMAC) — never trust an unauthenticated webhook.
- **Ack fast (2xx) then process async** — do the work in a queue/job, not in the request, or the
  sender will time out and retry.
- **Expect duplicates & retries** — process idempotently (dedupe by event id).

---

## Asynchronous Messaging: Decoupling Services

Move slow or fan-out work off the request path. The user isn't blocked; a worker processes later.

```
Client → API (accept, enqueue, return 202) ──▶ [ queue / broker ] ──▶ Worker(s) process
```
Benefits: faster responses, load leveling (absorb spikes), resilience (work waits if a consumer is
down), and decoupling (producer doesn't know consumers). → also [scaling-and-performance.md](./scaling-and-performance.md)

### Queue vs Pub/Sub vs Stream
| Model | Semantics | Tools | Use for |
|-------|-----------|-------|---------|
| **Work queue** | Each message → **one** consumer (competing consumers) | RabbitMQ, SQS, Redis, Sidekiq/Celery/BullMQ | Distribute tasks (emails, thumbnails, jobs) |
| **Pub/Sub** | Each message → **all** subscribers (fan-out) | Redis Pub/Sub, SNS, NATS, Google Pub/Sub | Notify many consumers of an event |
| **Event stream / log** | Durable, ordered, **replayable** log; consumers track offsets | **Kafka**, Pulsar, Kinesis, Redis Streams | Event sourcing, analytics, replay, high throughput |

**Queue vs stream** is a key decision:
- A **queue** typically deletes a message once acknowledged; good for "do this task once".
- A **stream** (Kafka) keeps events for a retention window; many independent consumer groups read
  at their own pace and can **replay** from any offset. Choose streams when you need history,
  multiple independent consumers, or very high throughput with ordering per partition.

---

## Delivery Guarantees (know which you have)

| Guarantee | Meaning | Reality |
|-----------|---------|---------|
| **At-most-once** | May lose messages, never duplicates | Fire-and-forget; only for tolerant data |
| **At-least-once** | Never lost, **may duplicate** | The common default — **design for duplicates** |
| **Exactly-once** | Never lost, never duplicated | Very hard end-to-end; usually *effectively-once* via idempotency + dedup |

Since at-least-once is the norm, **idempotent consumers are mandatory**: dedupe by a message/event
id, or make the operation naturally idempotent (upsert, set-to-value). "Exactly-once" in practice =
at-least-once delivery + idempotent processing.

---

## Ordering, Partitioning, and Consistency

- **Global ordering is expensive.** Kafka guarantees order only **within a partition**. Choose a
  partition key (e.g., `orderId`) so all events for one entity land in the same partition and stay
  ordered; different entities parallelize across partitions.
- Consumers must tolerate **out-of-order** and **duplicate** events across entities.
- Async messaging = **eventual consistency**: the read side lags the write. The domain/UI must
  handle the in-between (e.g., "payment processing…").

---

## Failure Handling

| Mechanism | Purpose |
|-----------|---------|
| **Ack/nack** | Consumer acknowledges only after successful processing; unacked → redelivered |
| **Retry with backoff** | Retry transient failures; exponential backoff + jitter |
| **Dead-letter queue (DLQ)** | After N failed attempts, park the message for inspection instead of infinite retry |
| **Poison-message handling** | Detect messages that always fail; DLQ them so they don't block the queue |
| **Idempotency** | Safe reprocessing after redelivery |
| **Backpressure** | Bound queue depth; shed/slow producers (429) when consumers fall behind |

**Backpressure** matters: if a queue grows without bound, it exhausts memory/disk and latency
explodes. Limit queue size, apply back pressure to producers, and alert on **consumer lag**
(the key health metric for streams/queues).

---

## The Outbox Pattern (reliable publish)

To change the DB **and** publish an event atomically, write the event to an `outbox` table in the
same transaction, then relay it to the broker. Prevents lost/ghost events (the dual-write problem).
Full details in [microservices-and-distributed.md](./microservices-and-distributed.md).

---

## Event-Driven Patterns

- **Event notification**: "something happened" (`OrderPaid`) — consumer calls back for details.
  Small events, low coupling.
- **Event-carried state transfer**: event includes the data consumers need — no callback, more
  autonomy, but larger events and duplicated data.
- **Event sourcing / CQRS**: persist events as the source of truth; build read models from them.
  → [microservices-and-distributed.md](./microservices-and-distributed.md)
- **Schema management**: version event schemas; use a schema registry (Avro/Protobuf/JSON Schema);
  evolve compatibly (add optional fields, don't repurpose meaning). Consumers and producers deploy
  independently, so contracts must stay compatible.

---

## When to Stay Synchronous

Async adds real complexity (eventual consistency, tracing across hops, ordering, DLQs). Prefer
synchronous when:
- The caller genuinely needs the result now (read queries, interactive validation).
- The operation is fast and cheap.
- Strong immediate consistency is required and a single transaction can provide it.

Use async when work is slow, fan-out, spiky, or must survive downstream outages.

---

## Anti-Patterns

- ❌ **Assuming exactly-once** — building consumers that break on duplicate delivery.
- ❌ **No DLQ** — a poison message retries forever and blocks the queue.
- ❌ **Processing webhooks synchronously** — heavy work in the request → sender times out and retries.
- ❌ **WebSocket state in process memory** — breaks the moment you run more than one instance.
- ❌ **Unbounded queues / ignoring consumer lag** — silent backlog until the broker falls over.
- ❌ **Needing global ordering** — fighting the partition model instead of keying by entity.
- ❌ **Events as commands** — coupling a producer to a specific consumer's action ("send email now")
  instead of announcing a fact ("order placed").
- ❌ **Async for everything** — adding a queue to a fast synchronous read for no reason.
