# Backend Reasoning Protocol — Engineer Like a Principal on Any Model

> "Prioritize transparency by explicitly showing reasoning steps. Gain ground truth from the
> environment at each step." — Anthropic, *Building Effective Agents*

This reference makes *any* Copilot model approach backend work like a principal engineer. A good
backend solution is not the one with the most technology — it is the one whose every decision
traces back to a requirement, states its trade-off, and is calibrated to the system's real scale
and phase. Weaker models jump to code, ignore non-functional requirements, and add complexity
they don't need. This protocol forces discipline.

**Read this first for any backend task.** It governs *how to reason*; the other references govern
*what to build*.

---

## The Loop — FRAME · MODEL · DESIGN · BUILD · HARDEN · PROVE

```
 FRAME ──→ MODEL ──→ DESIGN ──→ BUILD ──→ HARDEN ──→ PROVE
   │         │          │          │          │          │
 capture   model      choose     write      make it    test it,
 reqs,     domain     HLD +      idiomatic  secure,    find root
 scale,    & data,    LLD, arch  production fast,      cause, fix
 SLOs,     define     style &    -ready     scalable,  safely,
 limits    contracts  patterns   code       observable ship-gate
(ground                                     resilient
 truth)
```

| Stage | Mandate | Gate before leaving |
|-------|---------|---------------------|
| **FRAME** | Capture functional + non-functional requirements; quantify scale; log assumptions. | "Can I state the QPS, data size, latency budget, availability target, and consistency need?" |
| **MODEL** | Model the domain and data; choose stores by access pattern; define contracts. | "Do I know every entity, its access patterns, and the stable contracts?" |
| **DESIGN** | Pick the simplest architecture meeting the NFRs; do LLD for core modules. | "Does every structural choice trace to a requirement? Is anything over-built?" |
| **BUILD** | Implement with clean layering, validation, error handling, config, logging. | "Is input validated at the boundary? Are errors and config handled properly?" |
| **HARDEN** | Add security, caching, scaling headroom, resilience, observability. | "Would this survive an attacker, a traffic spike, and a dependency outage?" |
| **PROVE** | Test the pyramid; for bugs, fix root cause + regression test. | "Is there a test that would catch this breaking? Did I fix the cause, not the symptom?" |

> **Prime directive**: *No design decision without a requirement behind it; no recommendation
> without a stated trade-off; no "production-ready" claim without security, observability, and tests.*

---

## Why This Makes Weak Models Engineer Well

| Weak-model failure | What this protocol forces |
|--------------------|---------------------------|
| Jumps straight to code | **FRAME first**: requirements and scale before any design |
| Ignores non-functional requirements | **NFR quantification**: numbers for QPS, latency, availability, consistency |
| Picks trendy tech (microservices, Kafka, K8s) reflexively | **Requirement traceability + scale calibration**: simplest thing that works |
| Same answer regardless of context | **Scale & phase calibration**: MVP ≠ 100M-user platform |
| Bolts security/observability on last | **HARDEN is a first-class stage**, designed in, not added |
| Fixes the symptom of a bug | **ROOT-cause discipline** in PROVE: 5-Whys + regression test |
| Over-engineers "for the future" | **YAGNI gate**: build for the requirement in front of you |
| Claims "done" without proof | **PROVE gate**: tests + checklist before shipping |

---

## Stage 1 — FRAME: Ground Truth of the Problem

You cannot design what you have not framed. Before proposing anything:

1. **Functional requirements** — what must the system do? List the core use cases and workflows.
2. **Non-functional requirements (NFRs)** — quantify them, because NFRs drive architecture:
   - Traffic: average & **peak QPS**, read:write ratio, growth rate.
   - Data: volume today, growth/year, item size, retention.
   - Latency: **p50/p95/p99 budgets** per operation.
   - Availability: target 9s (99.9%? 99.99%?) and acceptable downtime.
   - Consistency: strong vs eventual, per data set.
   - Security/compliance: authn, authz, PII, regulatory constraints.
   - Cost & team: budget, team size/skills, deadline.
3. **Constraints & assumptions** — existing systems, must-use tech, integration points. Write
   assumptions down explicitly; unstated assumptions are the #1 cause of wrong designs.
4. **Brownfield discovery** (existing systems) — map endpoints, data flows, dependencies, current
   SLOs, and incident history *before* changing anything. → [requirements-and-estimation.md](./requirements-and-estimation.md)

> **Anti-pattern — designing from vibes**: "let's use microservices and Kafka" before knowing the
> load is 10 requests/minute. Every technology is a cost; justify each with a requirement.

---

## Stage 2 — MODEL: Domain, Data & Contracts

Most backend complexity is *data* complexity, and data decisions are the hardest to reverse.

1. **Model the domain** — entities, value objects, aggregates, relationships, bounded contexts.
2. **Choose stores by access pattern** — SQL vs NoSQL is decided by *how you read and write*,
   not fashion. A relational, transactional workload wants SQL; a high-write, key-lookup or
   flexible-document workload may want NoSQL.
3. **Define contracts** — the API and event schemas others depend on. Contracts are the most
   expensive thing to change once published; design them deliberately (versioning from day one).

> **Anti-pattern — schema-last**: bolting a data model onto code written first. Model the data
> and access patterns before you pick indexes or write queries.
> → [data-modeling-and-databases.md](./data-modeling-and-databases.md)

---

## Stage 3 — DESIGN: HLD + LLD (Simplest That Meets the NFRs)

Design at two levels, and bias toward simplicity.

**High-Level Design (HLD)** — the shape of the *system*:
- Choose an architecture style justified by FRAME. **Default to a modular monolith** unless the
  requirements (independent scaling, many autonomous teams, clear bounded contexts) demand
  distribution. "Monolith first" is the low-risk path; you can extract services later.
- Draw the components and how data flows between them (C4 is a useful notation).
- Record the decision and its trade-offs as an ADR.

**Low-Level Design (LLD)** — the shape of the *code*:
- Apply SOLID, DDD tactical patterns, and appropriate design patterns.
- Choose a layering (clean / hexagonal) that keeps business logic independent of frameworks.
- Model errors and concurrency explicitly — do not leave them to chance.

> **The complexity budget**: every layer, service, queue, and cache is a withdrawal. Spend only
> where a requirement demands it. → [architecture-styles.md](./architecture-styles.md),
> [low-level-design.md](./low-level-design.md)

---

## Stage 4 — BUILD: Production-Ready by Construction

Write code that is production-ready from the first commit, not retrofitted:
- Clean layering (transport → service/domain → data), dependencies pointing inward.
- **Validate all input at the boundary**; never trust client data.
- Consistent, structured **error handling** (no swallowed exceptions).
- **Config in the environment**; secrets in a vault (12-Factor).
- **Structured logging** with a correlation/request ID from the start.
- Tests written alongside the code, not "later".

→ [implementation-playbook.md](./implementation-playbook.md),
[tech-stack-guide.md](./tech-stack-guide.md)

---

## Stage 5 — HARDEN: Survive Users, Load, and Attackers

Working ≠ production-ready. Harden across five axes, sequenced by risk:

1. **Security first** — the highest-blast-radius category. Apply OWASP API Top 10 (2023) and Web
   Top 10; fix authz (BOLA/BFLA), auth, injection, SSRF, misconfig. → [security.md](./security.md)
2. **Resilience** — every remote call gets a timeout; add retries with backoff+jitter, circuit
   breakers, bulkheads, graceful degradation. → [production-readiness.md](./production-readiness.md)
3. **Performance & scale** — statelessness, load balancing, read replicas, connection pooling,
   kill N+1, rate-limit. → [scaling-and-performance.md](./scaling-and-performance.md)
4. **Caching** — the right layer and strategy with a plan for invalidation and stampedes.
   → [caching.md](./caching.md)
5. **Observability** — structured logs, RED/USE metrics, distributed tracing, health checks,
   and alerts, so you can *see* production. → [production-readiness.md](./production-readiness.md)

---

## Stage 6 — PROVE: Correct, Tested, and Fixable

1. **Test the pyramid** — many fast unit tests, fewer integration tests, few e2e tests, plus
   contract tests at service boundaries and load tests against the NFR budget.
   → [testing-strategy.md](./testing-strategy.md)
2. **Debug to root cause** — reproduce reliably, isolate, trace to the *cause* (5-Whys, blast
   radius), fix, and add a **regression test that fails before the fix and passes after**. Verify
   the fix introduces no new risk. → [bug-detection-and-fixing.md](./bug-detection-and-fixing.md)
3. **Gate the release** — run the consolidated checklist. → [checklist.md](./checklist.md)

---

## Scale Calibration — The Same Question Has Different Answers

The right design depends on scale. Never give a one-size answer.

| Dimension | Small (MVP / <1k users) | Medium (growth / 1k–1M) | Large (>1M users, high QPS) |
|-----------|-------------------------|-------------------------|-----------------------------|
| **Architecture** | Modular monolith, one DB | Monolith + read replicas + cache; extract hot services | Microservices/event-driven where justified |
| **Database** | Single Postgres/MySQL | Replicas, partial denormalization, targeted caching | Sharding, polyglot persistence, CQRS |
| **Async** | Inline or a simple queue | Managed queue for slow work | Event streaming (Kafka), backpressure |
| **Deploy** | One container / PaaS | Containers + autoscaling | Multi-AZ/region, service mesh |
| **Observability** | Logs + basic metrics | Metrics + tracing + alerts | Full SLO-driven observability, error budgets |

**Phase calibration**: greenfield MVPs optimize for *learning speed and reversibility* — favor
simplicity. Scaling and mature systems optimize for *reliability under load* — invest in the
harden/prove stages. Security stays high in every phase once real users or data exist.

---

## Assumption & Trade-off Logging

For every significant decision, record it (a lightweight ADR):

```
DECISION: <what was decided>
CONTEXT:  <the requirement/constraint that forced it>
OPTIONS:  <alternatives considered>
CHOICE:   <what and why>
TRADE-OFF: <what we give up / what could bite later>
REVISIT-WHEN: <the signal that this should be reconsidered, e.g. "QPS > 5k">
```

This makes designs reviewable and lets future engineers understand *why*, not just *what*.

---

## Confidence Calibration

State confidence on recommendations, and never present a guess as fact.

| Confidence | When | How to phrase |
|------------|------|---------------|
| **High** | Requirement is clear and the pattern is well-established | "Use X because requirement Y demands it." |
| **Medium** | Reasonable default but depends on unknowns | "Likely X; confirm the read:write ratio first." |
| **Low** | Genuinely uncertain / missing info | "Need to know Z before deciding; here are the options." |

When information is missing, **ask or state the assumption** — do not silently invent NFRs.

---

## Stopping Conditions

Stop when coverage — not exhaustion — is achieved:
- **FRAME** done when NFRs are quantified and assumptions logged.
- **DESIGN** done when every component and contract is justified by a requirement.
- **HARDEN** done when security, resilience, scale, and observability each have an explicit answer.
- **PROVE** done when the test pyramid covers the critical paths and the checklist passes.

Do **not** keep adding services, layers, caches, or abstractions "to be safe" — that is
over-engineering. The simplest system that meets the requirements is the correct one.
