# Requirements & Estimation (FRAME)

The first and most-skipped phase. A backend design is only as good as the requirements behind it.
This reference turns a vague ask into quantified requirements and a capacity estimate that drives
every later decision.

> **Rule**: Non-functional requirements (NFRs) drive architecture. "Store user orders" tells you
> almost nothing; "50k orders/day, 10:1 read:write, p99 < 200ms, 99.95% uptime, strong
> consistency on payment" tells you *what to build*.

---

## Functional vs Non-Functional Requirements

| Type | Question it answers | Examples |
|------|---------------------|----------|
| **Functional (FR)** | *What* must it do? | "Users can place orders", "Admins can refund", "Send receipt email" |
| **Non-functional (NFR)** | *How well* must it do it? | Latency, throughput, availability, consistency, security, cost, scalability |

**Capture functional requirements** as use cases / user stories with actors, triggers, and
outcomes. Identify the **critical paths** (money, identity, data integrity) — these get the
strictest NFRs and the most testing.

---

## The NFR Catalog — Quantify Each

Do not leave these as adjectives ("fast", "scalable"). Put numbers on them.

| NFR | What to capture | Typical unit |
|-----|-----------------|--------------|
| **Throughput** | Average and **peak** request rate; read:write ratio | requests/sec (QPS/RPS) |
| **Latency** | Budget per operation at percentiles | p50 / p95 / p99 in ms |
| **Data volume** | Current size, growth rate, item size, retention | GB/TB; rows/day |
| **Availability** | Uptime target; planned vs unplanned downtime | "nines" (99.9% = 8.7h/yr down) |
| **Consistency** | Per data set: strong vs eventual; staleness tolerance | e.g. "payment strong, feed eventual" |
| **Durability** | Acceptable data loss (RPO) and recovery time (RTO) | RPO/RTO in minutes |
| **Scalability** | Expected growth over 6–24 months | ×N users/QPS |
| **Security** | AuthN, authZ model, PII, compliance (GDPR/PCI/HIPAA) | classification + controls |
| **Cost** | Budget ceiling; cost per request/user | $/month |
| **Operability** | Team size/skills, on-call, deploy cadence | context |

### Availability "nines" cheat sheet
| Target | Downtime/year | Downtime/month | Notes |
|--------|---------------|----------------|-------|
| 99% | 3.65 days | 7.2 h | Internal tools |
| 99.9% (three 9s) | 8.77 h | 43.8 min | Typical SaaS |
| 99.99% (four 9s) | 52.6 min | 4.4 min | Serious platform (multi-AZ) |
| 99.999% (five 9s) | 5.26 min | 26 s | Very expensive; multi-region |

> Availability compounds: two required services at 99.9% in series → 99.8%. Redundant components
> in parallel *increase* availability. Fewer hops on the critical path = higher availability.

---

## SLA / SLO / SLI

| Term | Meaning | Example |
|------|---------|---------|
| **SLI** (Indicator) | A measured metric | "% of requests < 200ms", "% of successful requests" |
| **SLO** (Objective) | Internal target for an SLI | "99.9% of requests succeed over 30 days" |
| **SLA** (Agreement) | External promise + penalty | "99.9% uptime or credit" |

**Error budget** = 100% − SLO. A 99.9% SLO allows 0.1% failures — spend that budget on releasing
features; when it's exhausted, freeze risky changes. SLOs, not gut feeling, decide how much to
invest in the HARDEN phase.

---

## Back-of-the-Envelope Capacity Estimation

Estimate before you design. You need only rough magnitudes to choose an architecture.

### Step 1 — Traffic
```
Daily active users (DAU) × actions/user/day = daily requests
Average QPS  = daily requests / 86,400
Peak QPS     ≈ average QPS × (2 to 10)   # depends on spikiness; pick from traffic shape
Read QPS     = write QPS × read:write ratio
```
Example: 1M DAU × 20 actions = 20M req/day → ~230 avg QPS → ~1,150 peak QPS at 5×.

### Step 2 — Storage
```
new items/day × item size × retention(days) = active storage
add indexes (~20–100% overhead) + replication factor (×2–3) + growth headroom
```
Example: 20M writes/day × 1 KB × 365 × 3 (replicas) ≈ 22 TB/year raw.

### Step 3 — Bandwidth
```
egress = read QPS × response size ;  ingress = write QPS × request size
```

### Step 4 — Memory (cache)
Apply the 80/20 rule: cache the hot 20% of data serving 80% of reads.
```
cache size ≈ hot-item count × item size   (then round up for overhead)
```

### Powers of two & latency numbers (memorize the magnitudes)
```
2^10 ≈ 1 thousand (KB)   2^20 ≈ 1 million (MB)   2^30 ≈ 1 billion (GB)   2^40 ≈ 1 trillion (TB)

L1 cache        ~0.5 ns      Main memory      ~100 ns
Mutex lock      ~25 ns       SSD random read  ~150 µs
1 KB over 1Gbps ~10 µs       Datacenter RTT   ~500 µs
Disk seek       ~10 ms       CA→NL→CA RTT     ~150 ms
```
Rules of thumb: memory is ~100k× faster than disk seek; a cross-region round trip (~150ms) can
blow a latency budget on its own — count your network hops.

---

## Traffic Shape Matters

The peak-to-average ratio changes the architecture:
- **Steady** (internal API): peak ≈ 2× avg → provision for peak, simple autoscaling.
- **Diurnal** (consumer app): peak ≈ 3–5× avg → autoscale on schedule + metric.
- **Spiky** (ticket sales, flash sales, virality): peak ≈ 10–100× avg → queue-based load
  leveling, aggressive caching, rate limiting, possibly serverless for the spike.

---

## Consistency & Freshness Requirements (per data set)

Decide *per data set*, not globally:

| Data | Typical need | Why |
|------|-------------|-----|
| Payments, balances, inventory decrement | **Strong** | Double-spend / oversell is unacceptable |
| User profile, settings | Read-your-writes | User must see their own change immediately |
| Social feed, counts, analytics | **Eventual** | Slight staleness is fine; scale matters more |
| Search index | Eventual (seconds–minutes) | Rebuilt asynchronously |

This directly informs SQL vs NoSQL, replication read/write routing, and caching TTLs.

---

## Brownfield Discovery (Existing Systems)

Before changing an existing backend, build ground truth. **Understand before you touch.**

```bash
# 1. Inventory endpoints/routes (adapt per stack)
grep -rEn "@(Get|Post|Put|Delete|Patch)Mapping|app\.(get|post|put|delete|patch)|@router\.|MapGet|MapPost|HandleFunc" .
# 2. Data stores & connections
grep -rEn "postgres|mysql|mongodb|redis|kafka|rabbitmq|dynamodb|DATABASE_URL|ConnectionString" .
# 3. External dependencies
grep -rEn "http[s]?://|fetch\(|axios|HttpClient|requests\.|WebClient" . | head -50
# 4. Background jobs / schedulers
grep -rEn "cron|schedule|@Scheduled|celery|sidekiq|BackgroundService|Hangfire" .
# 5. Config & secrets (spot risky hardcoding)
grep -rEn "(api[_-]?key|secret|password|token)\s*[:=]" . | head -50
```

Capture:
- **System map**: services, data stores, queues, external integrations, and how requests flow.
- **Current SLOs / actual metrics**: latency, error rate, throughput (from logs/APM if available).
- **Pain points & incident history**: where it breaks, what pages people, known tech debt.
- **Constraints**: what cannot change (public contracts, compliance, data migration cost).

Only then choose the smallest change that addresses the requirement (see the brownfield path in
`SKILL.md` — discover → locate → route → root → verify).

---

## Output of the FRAME Phase

Produce a short **requirements brief** before designing:

```
SYSTEM: <name / one-line purpose>
FUNCTIONAL: <bullet list of core capabilities + critical paths>
NFRs:
  Throughput:  avg __ QPS, peak __ QPS, read:write __:__
  Latency:     p95 __ ms, p99 __ ms (per key operation)
  Data:        __ now, +__/year, item ~__ KB, retain __
  Availability: __ nines (downtime budget __)
  Consistency: <per data set>
  Security:    authn __, authz __, PII? __, compliance __
  Cost/Team:   budget __, team __, deadline __
ASSUMPTIONS: <explicit list — everything you inferred>
CONSTRAINTS: <existing systems, must-use tech, integrations>
```

This brief is the contract for the DESIGN phase — every architectural choice must trace back to it.

---

## Anti-Patterns

- ❌ **Adjective requirements** — "fast", "scalable", "secure" with no numbers.
- ❌ **Designing for imaginary scale** — building for 1B users when you have 100. (Nor the reverse.)
- ❌ **Global consistency** — forcing strong consistency everywhere when most data tolerates staleness.
- ❌ **Ignoring peak** — provisioning for average QPS and falling over at the daily spike.
- ❌ **Skipping brownfield discovery** — editing an unfamiliar system before mapping it.
- ❌ **Unstated assumptions** — inventing NFRs silently instead of asking or logging them.
