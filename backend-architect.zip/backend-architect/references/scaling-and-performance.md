# Scaling & Performance (HARDEN)

How to make a backend fast under load and able to grow. This reference covers scaling axes, load
balancing, the CAP trade-off, database scaling, rate limiting, and the performance bugs (N+1,
connection exhaustion) that sink real systems.

> **Rule**: Measure before you optimize. Find the actual bottleneck (profile, read query plans,
> check metrics) — don't guess. Then scale the bottleneck, not everything.

---

## Vertical vs Horizontal Scaling

| Axis | What | Pros | Cons |
|------|------|------|------|
| **Vertical (scale up)** | Bigger machine (CPU/RAM) | Simple, no code change | Hard ceiling, expensive, single point of failure |
| **Horizontal (scale out)** | More machines behind a load balancer | Near-limitless, fault-tolerant | Requires **stateless** apps + coordination |

Scale up first for simplicity; scale out for resilience and beyond a single box. Horizontal scaling
is the path to high availability — but only if the app is stateless.

---

## Statelessness — The Prerequisite for Scaling Out

App servers must hold **no client state** between requests, so any instance can serve any request
and you can add/remove instances freely.
- Store sessions in a shared store (Redis/DB), not in process memory.
- Don't keep user files/uploads on local disk — use object storage (S3/GCS/Blob).
- Don't rely on in-process caches for correctness (they diverge across instances).
- WebSocket state needs a backplane. → [realtime-and-messaging.md](./realtime-and-messaging.md)

> A single stateful assumption (in-memory session) behind a load balancer causes "randomly logged
> out" bugs the moment you run two instances.

---

## Load Balancing

Distributes requests across instances; also removes unhealthy nodes and enables zero-downtime deploys.

| Aspect | Options |
|--------|---------|
| **Layer 4** (transport) | Fast, routes by IP/port, no payload inspection |
| **Layer 7** (application) | Routes by path/header/cookie; TLS termination; smarter |
| **Algorithms** | Round-robin, weighted, least-connections, IP/consistent hash |
| **Health checks** | Poll a health endpoint; stop routing to failing nodes |
| **Session affinity** | "Sticky" sessions if state isn't shared (prefer shared state instead) |

Tools: Nginx, HAProxy, Envoy, cloud LBs (ALB/NLB, GCLB), Kubernetes Services + Ingress. Run
**multiple** LBs (active-active/passive) so the LB itself isn't a single point of failure.

---

## CAP & Consistency Under Distribution

In a distributed system that can be network-**P**artitioned, you must trade **C**onsistency vs
**A**vailability during a partition:
- **CP**: refuse/err on the minority side to stay consistent (banking, inventory).
- **AP**: keep serving possibly-stale data, reconcile later (feeds, catalogs, DNS).

Networks *will* partition, so this is a real choice, made **per data set**. Related: **PACELC** —
even without partitions, you trade latency vs consistency. Consistency models: strong,
read-your-writes, eventual. Match the model to the requirement (see
[requirements-and-estimation.md](./requirements-and-estimation.md)).

---

## Scaling the Database (usually the first bottleneck)

Order of operations (cheapest, highest-impact first):
1. **Fix slow queries & indexes** — read `EXPLAIN`; kill full scans on hot paths.
2. **Connection pooling** — DB connections are scarce and expensive; pool them (PgBouncer,
   HikariCP, built-in pools). Right-size the pool (too big overwhelms the DB; too small starves the app).
3. **Cache hot reads** — absorb repeated reads before they hit the DB. → [caching.md](./caching.md)
4. **Read replicas** — route reads to replicas, writes to primary. Mind **replication lag** (route
   read-your-writes to the primary).
5. **Denormalize / materialized views** — precompute expensive joins/aggregations.
6. **Partition / shard** — split data across nodes when one can't cope (last resort; high complexity).
→ Full detail in [data-modeling-and-databases.md](./data-modeling-and-databases.md).

---

## Killing the Common Performance Bugs

### N+1 queries (the #1 API latency bug)
One query to fetch a list, then one query **per item** to fetch a relation.
```
# ❌ N+1
orders = db.query("SELECT * FROM orders WHERE user_id=?", uid)   # 1
for o in orders: o.items = db.query("SELECT * FROM items WHERE order_id=?", o.id)  # N

# ✅ Fix: eager-load / join / batch
orders = db.query("SELECT * FROM orders WHERE user_id=?", uid)
items  = db.query("SELECT * FROM items WHERE order_id = ANY(?)", [o.id for o in orders])  # 1 more
# or a single JOIN, or an ORM eager-load (include/joinedload/Include/preload), or GraphQL DataLoader
```
Detect it: assert query count in integration tests; watch ORM query logs; APM span counts.

### Connection/resource exhaustion
Every DB/HTTP/file/socket handle must be released. Leaks exhaust pools and hang the service.
- Use the language's scope-bound cleanup (`with`/`using`/`defer`/try-with-resources).
- Bound and reuse pools; set acquisition timeouts so a leak fails fast instead of hanging.

### Other frequent culprits
- **Missing pagination** — endpoints returning unbounded result sets.
- **Synchronous slow work in the request** — offload to a queue. → [realtime-and-messaging.md](./realtime-and-messaging.md)
- **Chatty external calls** — batch, cache, or parallelize independent calls.
- **Serialization overhead** — large JSON payloads; select only needed fields; compress.
- **Lock contention** — long transactions/critical sections serialize everything.

---

## Rate Limiting & Load Shedding

Protect the system from overload and abuse (also OWASP API4).
| Algorithm | Behavior |
|-----------|----------|
| **Token bucket** | Allows bursts up to bucket size, refills at a steady rate (most common) |
| **Leaky bucket** | Smooths to a constant rate |
| **Fixed / sliding window** | Count per time window (sliding avoids edge bursts) |

- Return **429** with a `Retry-After` header; set limits per user/API-key/IP.
- Implement centrally (gateway/Redis) so limits hold across instances.
- **Load shedding**: when overloaded, reject low-priority work early (fail fast) to protect the core.
- **Backpressure**: bound queues and in-flight work; signal producers to slow down.

---

## Asynchronous Processing for Throughput

Move anything slow or bursty off the request path (emails, image processing, reports, third-party
calls). Accept fast (`202`), enqueue, process in workers, notify on completion. Improves p99 latency
and absorbs spikes (queue-based load leveling). → [realtime-and-messaging.md](./realtime-and-messaging.md)

---

## Autoscaling

- **Horizontal Pod/instance Autoscaling** on a signal: CPU, memory, RPS, or **queue depth/lag**
  (often the best signal for workers).
- **Scale-out fast, scale-in slow** to avoid flapping. Set min/max bounds.
- Ensure new instances are useful immediately (fast startup, warm caches/connection pools, readiness
  gates so traffic arrives only when ready).
- Watch the **downstream**: scaling app servers can overwhelm the DB — scale the whole path.

---

## Performance Methodology

1. **Define the budget** from NFRs (p95/p99 targets, target QPS).
2. **Load test** to find where it breaks. → [testing-strategy.md](./testing-strategy.md)
3. **Profile / trace** the bottleneck (CPU flame graphs, DB query plans, span timings).
4. **Fix the biggest bottleneck** (often DB or an N+1), then re-measure.
5. **Repeat** until the budget is met. Don't micro-optimize code that isn't the bottleneck.

Key metrics: latency percentiles (**p95/p99**, not average — averages hide tail pain), throughput,
error rate, saturation (CPU/mem/connections/queue depth). → [production-readiness.md](./production-readiness.md)

---

## Anti-Patterns

- ❌ **Optimizing without measuring** — guessing at the bottleneck; tuning the wrong thing.
- ❌ **Stateful app servers** behind a load balancer — breaks scaling and causes flaky sessions.
- ❌ **N+1 queries** — the silent latency killer; verify query counts in tests.
- ❌ **No connection pooling / pool too large** — exhaustion, or overwhelming the DB.
- ❌ **Unbounded result sets** — endpoints with no pagination or `limit` cap.
- ❌ **Sharding prematurely** — massive complexity before a single node is stressed.
- ❌ **Scaling app tier only** — pushing the bottleneck onto an unscaled database.
- ❌ **Averages instead of percentiles** — a great average with a terrible p99 still hurts users.
- ❌ **No rate limiting** — one abusive client or retry storm takes everyone down.
