# Security (HARDEN)

Security is the highest-blast-radius category — one flaw can compromise the whole system and its
users' data. This reference maps the **OWASP API Security Top 10 (2023)** and the **OWASP Top 10
(Web)** to concrete backend defenses, plus authn/authz, input handling, secrets, and encryption.

> **Rule**: Never trust client input, and check authorization on **every** access to an
> object or function using the *server's* notion of identity — never a client-supplied id/role.
> Secure by default; make the safe path the easy path.

---

## OWASP API Security Top 10 (2023) — What & How to Defend

| # | Risk | Defense |
|---|------|---------|
| **API1** | **Broken Object Level Authorization (BOLA)** | On every request that takes an object id, verify the authenticated user owns/may access **that** object. Don't trust `?userId=`. #1 API vuln. |
| **API2** | **Broken Authentication** | Strong token handling; short-lived access tokens + rotation; verify signature/issuer/audience/expiry; lock out brute force; secure password storage (argon2/bcrypt). |
| **API3** | **Broken Object Property Level Authorization** | Whitelist which fields a role may read/write. Don't bind requests straight to entities (mass assignment); don't return whole objects (excessive data exposure). |
| **API4** | **Unrestricted Resource Consumption** | Rate limits, quotas, pagination caps, payload size limits, timeouts, and limits on expensive ops (uploads, fan-out, third-party calls). Prevents DoS & cost blowups. |
| **API5** | **Broken Function Level Authorization (BFLA)** | Enforce role/permission checks on every function/route, especially admin/privileged ones. Deny by default. |
| **API6** | **Unrestricted Access to Sensitive Business Flows** | Protect flows abusable by automation (signup, purchase, comment) with rate limits, bot detection, CAPTCHAs where appropriate. |
| **API7** | **Server-Side Request Forgery (SSRF)** | Validate/allowlist any user-supplied URL the server fetches; block internal IP ranges & metadata endpoints; disable redirects to internal hosts. |
| **API8** | **Security Misconfiguration** | Harden defaults; disable debug/verbose errors in prod; set security headers; patch; least-privilege infra; review CORS. |
| **API9** | **Improper Inventory Management** | Track all APIs/versions/environments; retire shadow/zombie/deprecated endpoints; keep docs current. |
| **API10** | **Unsafe Consumption of APIs** | Validate and sanitize data from third-party/upstream APIs too; don't blindly trust their responses; timeout & sandbox integrations. |

---

## OWASP Top 10 (Web) — Backend-Relevant Highlights

| Category | Backend defense |
|----------|-----------------|
| **Broken Access Control** | Deny by default; centralize authz; test object/function-level checks (overlaps API1/API5). |
| **Cryptographic Failures** | TLS everywhere; encrypt sensitive data at rest; strong algorithms; no home-rolled crypto. |
| **Injection** (SQL/NoSQL/OS/LDAP) | Parameterized queries/ORM; validate & escape; never build queries/commands from raw input. |
| **Insecure Design** | Threat-model critical flows; build in security from the design phase, not after. |
| **Security Misconfiguration** | Least privilege, hardened configs, no default creds, minimal error detail. |
| **Vulnerable/Outdated Components** | Scan deps (npm/pip/mvn/dotnet/govulncheck); patch; pin & verify. |
| **Identification & Auth Failures** | Robust session/token management; MFA where warranted; brute-force protection. |
| **Software & Data Integrity Failures** | Verify package integrity; secure CI/CD; sign artifacts; guard deserialization. |
| **Logging & Monitoring Failures** | Log security events (authn/authz failures) without secrets; alert on anomalies. |
| **SSRF** | Allowlist outbound URLs; block internal ranges (overlaps API7). |

---

## Authentication (proving identity)

| Mechanism | Use / notes |
|-----------|-------------|
| **Session + cookie** | Server-side session store; cookie `HttpOnly`, `Secure`, `SameSite`. Simple, easy to revoke. |
| **JWT (access token)** | Stateless; verify **signature, `iss`, `aud`, `exp`**; keep **short-lived**; store server secret safely. Can't easily revoke → keep TTL short + a revocation list for logout. |
| **Refresh tokens** | Long-lived, stored securely, **rotated** on use; detect reuse (token theft). |
| **OAuth2 / OIDC** | Delegated auth / SSO / third-party login; use a vetted library, never hand-roll flows. |
| **API keys / mTLS** | Service-to-service; scope keys; rotate; mTLS for strong mutual auth. |

- **Password storage**: `argon2id` (preferred) or `bcrypt`; never MD5/SHA-1/plaintext; add per-user
  salt (built into these). Enforce sane password policies; check against breach lists.
- **Brute-force**: rate-limit + progressive lockout on auth endpoints; constant-time comparison for
  secrets to avoid timing leaks.

---

## Authorization (what identity may do)

- **Deny by default**: no access unless explicitly granted.
- **Object-level (BOLA)**: the authenticated principal may act on *this* record. Load by owner
  (`WHERE id=? AND user_id=?`) or check ownership after load. Never use a client-supplied identity.
- **Function-level (BFLA)**: this principal's role/permission allows this operation (esp. admin).
- **Models**: **RBAC** (roles → permissions), **ABAC** (attributes/policies), **ReBAC**
  (relationship-based, e.g. Google Zanzibar) for complex sharing. Centralize the check; don't
  scatter ad-hoc `if role ==` across the codebase.
- **Multi-tenancy**: always scope every query by tenant; a missing tenant filter leaks across
  customers.

---

## Input Handling

- **Validate at the boundary**: type, format, length, range, allowed set — reject the rest. Positive
  (allowlist) validation beats trying to blocklist bad input.
- **Injection prevention**: parameterized queries/ORM for SQL & NoSQL; avoid shell-outs (use APIs);
  if unavoidable, pass args as arrays (no shell string). Never interpolate input into queries/commands.
- **Output encoding**: encode data for its sink; even for APIs, set correct `Content-Type` and
  avoid reflecting raw input.
- **Mass assignment**: bind to explicit DTOs, not entities; whitelist writable fields.
- **Deserialization**: don't deserialize untrusted data into arbitrary types; use safe formats/settings.
- **File uploads**: validate type/size; store outside webroot / in object storage; scan; generate
  new names; never execute uploads.

---

## Secrets & Configuration

- **No secrets in source control or images.** Use a secret manager (Vault, AWS/GCP/Azure secrets,
  Doppler). Inject via env at runtime.
- **Rotate** credentials; scope them least-privilege; separate per environment.
- **Detect leaks**: pre-commit secret scanning (gitleaks/trufflehog); if leaked, **rotate
  immediately** (removing from history is not enough).
- **.env** files are for local dev only and must be git-ignored.

---

## Transport & Data Protection

- **TLS everywhere** (HTTPS, and mTLS or TLS between internal services); redirect HTTP→HTTPS; HSTS.
- **Encrypt sensitive data at rest** (DB/disk encryption; field-level for the most sensitive, e.g.
  tokens, PII).
- **Minimize data**: don't collect/return/store what you don't need; mask/tokenize PII; define
  retention.

---

## HTTP Security Hygiene

- **Security headers**: `Strict-Transport-Security`, `X-Content-Type-Options: nosniff`,
  `X-Frame-Options`/CSP `frame-ancestors`, `Content-Security-Policy`, `Referrer-Policy`.
- **CORS**: allowlist specific origins/methods/headers; **never** reflect arbitrary `Origin` with
  credentials. Default deny.
- **Cookies**: `HttpOnly`, `Secure`, `SameSite=Lax/Strict`.
- **CSRF**: for cookie-based auth, use anti-CSRF tokens or `SameSite`; token-based APIs are less
  exposed but still mind cross-origin.
- **Error responses**: generic messages to clients; details to logs only.

---

## Supply Chain & Dependencies

- Scan dependencies for CVEs in CI (`npm audit`, `pip-audit`, `mvn dependency-check`,
  `dotnet list package --vulnerable`, `govulncheck`, `cargo audit`).
- Pin versions and use a lockfile; review new dependencies (typosquatting, abandoned packages).
- Generate an **SBOM**; keep base images minimal and patched; run containers as **non-root**.

---

## Red Flags (grep)

```bash
# Hardcoded secrets
grep -rEn "(password|passwd|secret|api[_-]?key|token|private[_-]?key)\s*[:=]\s*['\"][^'\"]{6,}" .
# String-built SQL (injection)
grep -rEn "(SELECT|INSERT|UPDATE|DELETE).*(\+|\$\{|%s|f\"|\|\|).*(FROM|WHERE|SET|INTO)" .
# Shell execution with input
grep -rEn "exec\(|system\(|os\.system|subprocess.*shell=True|Runtime\.getRuntime|child_process" .
# Weak crypto / hashing
grep -rEn "md5|sha1|DES|ECB|Math\.random\(\)" .
# Trusting client identity / role
grep -rEn "req\.(query|body|params)\.(userId|role|isAdmin|tenantId)" .
# Permissive CORS
grep -rEn "Access-Control-Allow-Origin.*\*|origin:\s*true" .
# Disabled TLS verification
grep -rEn "rejectUnauthorized:\s*false|verify=False|InsecureSkipVerify|ServerCertificateValidationCallback" .
```

---

## Anti-Patterns

- ❌ **Trusting client-supplied identity/role** (`?userId=`, `isAdmin` in body) — the root of BOLA/BFLA.
- ❌ **String-concatenated SQL/commands** — injection.
- ❌ **Secrets in code/images/logs** — leaks that outlive the commit.
- ❌ **Home-rolled crypto/auth** — use vetted libraries and standards.
- ❌ **Returning entities / binding requests to entities** — over-exposure & mass assignment.
- ❌ **Verbose errors in prod** — stack traces/SQL handed to attackers.
- ❌ **`Access-Control-Allow-Origin: *` with credentials** — cross-origin data theft.
- ❌ **Skipping dependency scanning** — shipping known CVEs.
- ❌ **Authorization checks only in the UI** — the API must enforce them independently.
