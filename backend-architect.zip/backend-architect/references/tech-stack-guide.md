# Tech-Stack Guide (BUILD) — Any Backend, Idiomatically

The principles in this skill are universal; this reference maps them to idiomatic code across the
major backend stacks, helps you **choose** a stack for a new project, and helps you **detect and
work within** an existing/unknown one. **The concept is the same everywhere — only the syntax and
libraries change**, so the skill applies to *any* stack, including ones not listed here.

> **Rule**: Follow each ecosystem's idioms and conventions. Idiomatic code is what the next
> maintainer expects; fighting the framework creates permanent friction. For an existing codebase,
> **match what's already there** — don't introduce a second framework/ORM/pattern for one feature.

---

## Stack Selection Cheat-Sheet

| Stack | Sweet spot | Concurrency model | Notable strengths |
|-------|-----------|-------------------|-------------------|
| **Node.js/TS** (Express 5/NestJS/Fastify/Hono) | IO-bound APIs, real-time, JS everywhere, BFF | Async event loop | Huge ecosystem, fast to build, WebSockets, shared FE/BE types |
| **Python** (FastAPI/Django 5/Flask/Litestar) | APIs, data/ML-adjacent, rapid dev | async (FastAPI/Litestar) / sync (Django/Flask) | Readability, ecosystem, FastAPI = typed+async+OpenAPI |
| **Java** (Spring Boot 3/Quarkus/Micronaut) | Large enterprise systems, many teams | Threads + pools; **virtual threads (JDK 21+)**; WebFlux | Mature, robust, huge tooling, strong typing |
| **.NET** (ASP.NET Core 8/9) | Enterprise, high perf, Azure/cross-platform | async/await + thread pool | Very fast (top-tier), first-class async, superb tooling |
| **Go** (net/http, Gin, Echo, Fiber, Chi) | High-throughput services, infra, CLIs, cloud-native | Goroutines + channels | Simple, fast, small static binaries, great concurrency |
| **Rust** (Axum/Actix/Rocket) | Max performance, safety-critical, low footprint | async (Tokio) | Memory safety w/o GC, top-tier speed, correctness |
| **C# / Node / Go** | (general-purpose middle ground) | — | Balanced perf + productivity + hiring pool |
| **Ruby** (Rails 8) | Rapid product dev, CRUD-heavy apps, startups | Threads + background jobs | Convention over config, velocity, mature |
| **PHP** (Laravel 11/Symfony) | Web apps, CMS, rapid dev, cheap hosting | Process-per-request (+ workers) | Ubiquitous, batteries-included, huge install base |
| **Elixir** (Phoenix) | Real-time, high-concurrency, fault-tolerant, chat/IoT | BEAM actors (millions of processes) | Massive concurrency, resilience, LiveView, low latency |
| **Kotlin** (Ktor/Spring) | JVM with modern language, Android-adjacent teams | Coroutines | Concise, null-safe, JVM ecosystem |

**Emerging runtimes/frameworks worth knowing**: **Bun** (fast JS runtime + toolkit), **Deno**
(secure TS runtime), **Hono** (edge/serverless JS), **Litestar** (async Python), **Quarkus/
Micronaut** (fast-boot, native-image JVM for serverless/K8s). Also strong niche choices: **Scala**
(Play/http4s), **Clojure**, **Kotlin/Ktor**, **C++** (Drogon, for extreme throughput).

**Adoption & sentiment (Stack Overflow 2024, share of developers who *used* it)**: Node.js 41%,
Express 18%, ASP.NET Core 17%, Flask 13%, Spring Boot 13%, Django 12%, FastAPI 10%, Laravel 8%,
NestJS 6%, Rails 5%, Phoenix 2%. **Most-admired** backend frameworks: Phoenix (~84%), ASP.NET Core
(~72%), FastAPI (~65%), Spring Boot (~62%), NestJS (~61%). Most-admired **languages**: Rust (~82%),
Elixir (~77%), Go (~68%), TypeScript (~70%), Python (~68%), C# (~64%). Most-used **database**:
PostgreSQL (~49%, also the most desired). Use adoption as a proxy for **hiring pool, ecosystem
maturity, and community support** — real factors, not fashion.

**Raw performance (TechEmpower Round 23, 2025)**: Rust, C++, Java, C#/.NET, and Go frameworks lead
throughput; interpreted stacks (Python/Ruby/PHP) rank lower on raw req/s but are almost always
"fast enough" — the real bottleneck is usually the **database and network**, not the framework.
Don't pick a language for benchmark numbers you'll never hit.

---

## How to Choose a Stack — Decision Framework

There is no universally "best" backend stack — only the best fit for *this* team and problem. Weigh
these factors against the FRAME requirements (see [requirements-and-estimation.md](./requirements-and-estimation.md)):

| Factor | Questions | Weight guidance |
|--------|-----------|-----------------|
| **Team expertise** | What does the team already know deeply? | **Usually the #1 factor** — a team is 10× more productive and safer in a language it knows |
| **Ecosystem fit** | Are there mature libraries for your domain (payments, ML, streaming)? | High — reinventing libraries is expensive |
| **Performance profile** | IO-bound (most web APIs) or CPU-bound (encoding, ML, sims)? | IO-bound → almost any stack; CPU-bound → Go/Rust/Java/.NET |
| **Concurrency model** | Many concurrent connections (real-time/chat)? | Elixir/Go/async runtimes shine; avoid blocking models |
| **Scale trajectory** | MVP now, or known massive scale? | Don't over-optimize early; pick something you can scale *and* ship fast in |
| **Hiring pool** | Can you hire/retain for it in your market? | High for companies; adoption stats matter here |
| **Operational fit** | Cloud, container, serverless, existing platform? | Native-image/fast-boot (Go, Quarkus) for serverless/scale-to-zero |
| **Type safety** | How costly are runtime type bugs? | Static typing (TS/Java/.NET/Go/Rust/Kotlin) for large/long-lived systems |
| **Cost & licensing** | Hosting cost, license constraints? | Compiled langs = lower compute cost at scale |

### Scenario → sensible defaults
| Scenario | Reasonable choices |
|----------|-------------------|
| Startup MVP / CRUD product, ship fast | Rails, Django, Laravel, NestJS, FastAPI |
| Typed API, team likes JS/TS | NestJS or Fastify/Hono (TS) |
| Data/ML-adjacent API | FastAPI / Django (Python) |
| Large enterprise, many teams, strong typing | Spring Boot (Java) / ASP.NET Core (.NET) |
| High-throughput / cloud-native microservices, small binaries | Go (Gin/Echo/Chi) |
| Max performance / low footprint / safety-critical | Rust (Axum) / .NET / Java |
| Real-time, huge concurrent connections, fault tolerance | Elixir/Phoenix / Go / Node |
| Edge / serverless functions | Hono, Deno, Go, Quarkus/Micronaut (native image) |

> **Honest guidance**: for most teams and most products, the winning move is a **boring, mature,
> well-known stack the team already knows**, backed by PostgreSQL. Reserve exotic choices for
> requirements that genuinely demand them. And remember: you can build a modular monolith in any of
> these and extract hot services in a different stack later if a real bottleneck appears.

---

## Detecting & Working With an Existing Stack (Brownfield)

When you join or inherit a codebase, **identify the stack before you touch it**, then work strictly
within its conventions. Fingerprint from the manifest/lock files, config, and directory layout:

| Signal file(s) | Stack | Read for… |
|----------------|-------|-----------|
| `package.json` + lockfile (`package-lock.json`/`yarn.lock`/`pnpm-lock.yaml`/`bun.lockb`) | **Node.js/TS** | `dependencies` reveal framework (express/@nestjs/fastify/hono), ORM (prisma/typeorm/drizzle), test runner |
| `requirements.txt` / `pyproject.toml` / `Pipfile` / `poetry.lock` | **Python** | fastapi/django/flask/litestar; sqlalchemy/django-orm; pytest |
| `pom.xml` (Maven) / `build.gradle(.kts)` (Gradle) | **Java/Kotlin** | spring-boot-starter-*, quarkus, micronaut; JPA/jOOQ; JUnit |
| `*.csproj` / `*.sln` / `Directory.Packages.props` | **.NET** | `<TargetFramework>` = version; EF Core/Dapper; xUnit/NUnit |
| `go.mod` / `go.sum` | **Go** | module path, Go version, gin/echo/chi/fiber; sqlc/gorm |
| `Cargo.toml` / `Cargo.lock` | **Rust** | axum/actix/rocket; sqlx/sea-orm; tokio |
| `Gemfile` / `Gemfile.lock` | **Ruby** | rails version, sidekiq, rspec |
| `composer.json` / `composer.lock` | **PHP** | laravel/symfony version, phpunit |
| `mix.exs` / `mix.lock` | **Elixir** | phoenix, ecto, oban |
| `build.sbt` | **Scala** | play/http4s/akka |
| `Dockerfile` / `docker-compose.yml` | any | base image = runtime+version; linked services = DB/cache/broker |
| `.tool-versions` / `.nvmrc` / `.python-version` / `.ruby-version` | any | pinned runtime versions |
| `.env(.example)` / config files | any | DB URL, cache, broker, external services in use |

### Fingerprint commands
```bash
# What manifests exist? (identifies the stack in seconds)
ls -a | grep -Ei 'package\.json|requirements|pyproject|pom\.xml|build\.gradle|\.csproj|\.sln|go\.mod|cargo\.toml|gemfile|composer\.json|mix\.exs|build\.sbt|dockerfile'
# Runtime + framework versions
grep -Ei '"(express|@nestjs|fastify|hono)"|fastapi|django|flask|spring-boot|quarkus|axum|actix|gin-gonic|rails|laravel|phoenix' -r . | head
# Data stores / brokers actually wired
grep -rEi 'postgres|mysql|mongodb|redis|kafka|rabbitmq|dynamodb|elasticsearch' -r . | grep -Ei 'url|host|connection|dsn' | head
```

### Rules for contributing to an existing stack
1. **Match conventions**: mirror the existing folder layout, naming, error handling, and patterns
   already in the code — consistency beats your personal preference.
2. **Use what's already there**: the installed router/ORM/validation/test framework. Do **not** add
   a competing library (a second ORM, a new HTTP client) for one feature.
3. **Map the skill's concepts onto their code**: find where routing, validation, authz, the data
   layer, config, logging, and background jobs live, then apply the relevant reference file's
   guidance in *their* idiom.
4. **Read existing tests** to learn conventions and get a safety net before changing behavior.
5. **Respect the version**: check the framework/runtime version; don't use APIs newer than the
   project pins. Upgrades are a separate, deliberate change.
6. **Preserve public contracts** (API shapes, event schemas, DB schema) — evolve them compatibly.
   → [api-design.md](./api-design.md), [data-modeling-and-databases.md](./data-modeling-and-databases.md)

---

## Any Stack: Universal Backend Anatomy

Every server-side framework — listed here or not (Scala, Clojure, Haskell, Zig, Crystal, Perl,
Haxe, a bespoke in-house one) — exposes the **same building blocks**. Find each one, and you can
apply every concept in this skill regardless of language:

| Universal building block | What to look for | Skill concept it maps to |
|--------------------------|------------------|--------------------------|
| **Entry point / server bootstrap** | `main`, app factory, `listen()` | Composition root, config wiring |
| **Router / dispatcher** | route table, controllers, handlers | [api-design.md](./api-design.md) |
| **Middleware / interceptor pipeline** | auth, logging, error, CORS filters | cross-cutting concerns, authz |
| **Request context** | request/response objects, DI scope | correlation id, per-request state |
| **Validation** | schema/DTO/model binding | input validation at the boundary |
| **Data access** | ORM/query builder/driver + pool | [data-modeling-and-databases.md](./data-modeling-and-databases.md) |
| **Config & secrets** | env loading, settings object | 12-Factor config |
| **Async / background work** | job queue, scheduler, threads/goroutines | [realtime-and-messaging.md](./realtime-and-messaging.md) |
| **Error handling** | global handler, error types | consistent error contract |
| **Logging / telemetry** | logger, metrics, tracing hooks | [production-readiness.md](./production-readiness.md) |
| **Test harness** | test runner + fixtures | [testing-strategy.md](./testing-strategy.md) |

**Procedure for an unfamiliar stack**: (1) locate these building blocks in the docs/code; (2) learn
the idiomatic way to do each (read the framework's official "getting started" + a real handler);
(3) apply the skill's principles through that idiom. The *principles* — validate at the boundary,
object-level authz, parameterized queries, stateless + cache, timeouts/retries, structured logs,
test the pyramid — are **language-independent**.

---

## Concept → Stack Mapping

| Concept | Node (NestJS) | Python (FastAPI) | Java (Spring) | .NET (ASP.NET Core) | Go | Rust (Axum) |
|---------|---------------|------------------|---------------|---------------------|-----|-------------|
| Routing | `@Controller`/`@Get` | `@app.get` / `APIRouter` | `@RestController`/`@GetMapping` | `MapGet` / `[ApiController]` | `http.HandleFunc`/mux | `Router::route` |
| DI | Nest DI container | `Depends()` | Spring IoC (`@Autowired`) | built-in DI container | manual/wire | manual/state |
| Validation | class-validator | Pydantic models | Bean Validation (`@Valid`) | DataAnnotations/FluentValidation | validator pkg | `validator`/serde |
| ORM/DB | Prisma/TypeORM | SQLAlchemy/Tortoise | JPA/Hibernate, jOOQ | EF Core / Dapper | sqlc/GORM | sqlx/SeaORM |
| Async | async/await | async/await | CompletableFuture/WebFlux/virtual threads | async/await (Task) | goroutines | async/.await (Tokio) |
| AuthN | Passport/Guards | fastapi-users/deps | Spring Security | ASP.NET Identity/JWT | middleware | tower middleware |
| Config | @nestjs/config | pydantic-settings | application.yml/@Value | IConfiguration/Options | env/viper | config/env |
| Tests | Jest | pytest | JUnit + Mockito | xUnit/NUnit | testing pkg | cargo test |
| Migrations | Prisma Migrate | Alembic | Flyway/Liquibase | EF Core Migrations | golang-migrate | sqlx/refinery |
| Background jobs | BullMQ | Celery/RQ/arq | @Scheduled/Quartz | Hosted/Hangfire | goroutines/cron | tokio tasks |

---

## Layered structure per stack (where things go)

- **Node/NestJS**: `*.controller.ts` (transport) → `*.service.ts` (application) → domain classes →
  `*.repository.ts` (infra). Modules group a feature. Use DTO classes + `class-validator`.
- **Python/FastAPI**: `routers/` (transport) → `services/` (application) → `domain/` → `repositories/`.
  Pydantic models for request/response and settings; `Depends()` for DI.
- **Java/Spring**: `@RestController` → `@Service` → domain → `@Repository`. Packages by feature.
  DTOs (records) separate from JPA entities.
- **.NET/ASP.NET Core**: Minimal APIs or controllers → application services → domain → EF Core
  repos/`DbContext`. Records for DTOs; `Options<T>` for config.
- **Go**: `handler` → `service` → `domain` → `repository` packages; interfaces defined by the
  consumer; `internal/` to hide packages. Explicit error returns.
- **Rails**: controllers → service objects/POROs → models (keep models from becoming god objects) →
  jobs. Strong params for input.
- **Laravel**: controllers → actions/services → Eloquent models → jobs. Form Requests for validation.
- **Rust/Axum**: handlers → services → domain → repo traits; `serde` for (de)serialization,
  `Result<_, AppError>` everywhere.

---

## Representative Snippets — A Validated, Authorized Endpoint

The same idea (validate input → authorize on the object → delegate → typed response) in each stack.

**Node.js / NestJS**
```ts
@Controller('orders')
export class OrdersController {
  constructor(private readonly orders: OrdersService) {}

  @Get(':id')
  async get(@Param('id') id: string, @CurrentUser() user: User): Promise<OrderDto> {
    const order = await this.orders.findById(id);
    if (!order) throw new NotFoundException();
    if (order.userId !== user.id) throw new ForbiddenException(); // object-level authz (BOLA)
    return OrderDto.from(order);
  }
}
```

**Python / FastAPI**
```python
@router.get("/orders/{order_id}", response_model=OrderOut)
async def get_order(order_id: UUID, user: User = Depends(current_user),
                    svc: OrderService = Depends()):
    order = await svc.find_by_id(order_id)
    if order is None:
        raise HTTPException(404)
    if order.user_id != user.id:            # object-level authz (BOLA)
        raise HTTPException(403)
    return OrderOut.model_validate(order)
```

**Java / Spring Boot**
```java
@RestController @RequestMapping("/orders")
class OrderController {
  private final OrderService orders;
  OrderController(OrderService orders) { this.orders = orders; }

  @GetMapping("/{id}")
  OrderDto get(@PathVariable UUID id, @AuthenticationPrincipal AppUser user) {
    var order = orders.findById(id).orElseThrow(NotFoundException::new);
    if (!order.getUserId().equals(user.getId())) throw new ForbiddenException(); // BOLA
    return OrderDto.from(order);
  }
}
```

**.NET / ASP.NET Core (Minimal API)**
```csharp
app.MapGet("/orders/{id}", async (Guid id, ClaimsPrincipal principal, IOrderService svc) =>
{
    var order = await svc.FindByIdAsync(id);
    if (order is null) return Results.NotFound();
    if (order.UserId != principal.GetUserId()) return Results.Forbid();   // object-level authz (BOLA)
    return Results.Ok(OrderDto.From(order));
}).RequireAuthorization();
```

**Go (net/http + chi)**
```go
func (h *OrderHandler) Get(w http.ResponseWriter, r *http.Request) {
    id := chi.URLParam(r, "id")
    user := auth.UserFrom(r.Context())
    order, err := h.svc.FindByID(r.Context(), id)
    if errors.Is(err, ErrNotFound) { http.Error(w, "not found", http.StatusNotFound); return }
    if err != nil { http.Error(w, "internal", http.StatusInternalServerError); return }
    if order.UserID != user.ID { http.Error(w, "forbidden", http.StatusForbidden); return } // BOLA
    writeJSON(w, http.StatusOK, toOrderDTO(order))
}
```

**Rust (Axum)**
```rust
async fn get_order(
    State(svc): State<OrderService>, AuthUser(user): AuthUser, Path(id): Path<Uuid>,
) -> Result<Json<OrderDto>, AppError> {
    let order = svc.find_by_id(id).await?.ok_or(AppError::NotFound)?;
    if order.user_id != user.id { return Err(AppError::Forbidden); } // object-level authz (BOLA)
    Ok(Json(OrderDto::from(order)))
}
```

**Ruby / Rails**
```ruby
class OrdersController < ApplicationController
  before_action :authenticate_user!
  def show
    order = Order.find_by(id: params[:id])
    return head :not_found if order.nil?
    return head :forbidden unless order.user_id == current_user.id  # object-level authz (BOLA)
    render json: OrderSerializer.new(order)
  end
end
```

**PHP / Laravel**
```php
public function show(string $id, Request $request): JsonResponse {
    $order = Order::find($id);
    if (!$order) return response()->json(['title' => 'Not found'], 404);
    if ($order->user_id !== $request->user()->id)                    // object-level authz (BOLA)
        return response()->json(['title' => 'Forbidden'], 403);
    return response()->json(new OrderResource($order));
}
```

---

## Parameterized Queries (never concatenate)

| Stack | Safe form |
|-------|-----------|
| Node (pg) | `pool.query('SELECT * FROM orders WHERE id=$1', [id])` |
| Python | `cur.execute("SELECT * FROM orders WHERE id=%s", (id,))` / SQLAlchemy bound params |
| Java | `PreparedStatement` / JPA `:param` / jOOQ |
| .NET | EF Core LINQ / Dapper `new { id }` / parameterized `SqlCommand` |
| Go | `db.QueryContext(ctx, "... WHERE id=$1", id)` |
| Rust | `sqlx::query!("... WHERE id = $1", id)` (compile-time checked) |
| Rails/Laravel | ActiveRecord `where(id:)` / Eloquent `where('id', $id)` (bound) |

> String-interpolating user input into SQL is SQL injection. → [security.md](./security.md)

---

## Async / Blocking Gotchas by Runtime

- **Node.js / Python-async / .NET / Rust**: one event loop (or async runtime). **Never run
  blocking CPU or sync IO on it** — offload CPU to workers/threads; use async DB/HTTP clients. A
  forgotten `await` (JS/Py/C#) silently drops errors and ordering.
- **Java / .NET threads**: bounded thread pools — a slow downstream call can exhaust the pool
  (use timeouts, bulkheads, async, or virtual threads).
- **Go**: goroutines are cheap but **leak** if they block forever on a channel/context — always
  wire `context` cancellation and timeouts; close channels correctly to avoid deadlocks.
- **Rails/Laravel**: typically process/thread-per-request — push slow work to background jobs
  (Sidekiq/queues) rather than blocking the request.
- **Elixir/Phoenix**: lightweight BEAM processes handle massive concurrency, but a single process
  can still bottleneck — don't serialize all work through one GenServer; supervise and isolate.
- **JVM virtual threads (Java 21+/Kotlin)**: make blocking IO cheap again, but don't pin them with
  `synchronized` around IO; use them to simplify, not to ignore timeouts.

---

## Per-Stack Red Flags (grep)

```bash
# Hardcoded secrets (any stack)
grep -rEn "(password|secret|api[_-]?key|token)\s*[:=]\s*['\"][^'\"]+" .
# Node: sync IO on the event loop
grep -rEn "readFileSync|execSync|crypto\.pbkdf2Sync" .
# Python: blocking call in async / bare except
grep -rEn "except:\s*$|time\.sleep\(" .
# Java/.NET: async-over-sync deadlock risk
grep -rEn "\.Result|\.Wait\(\)|\.GetAwaiter\(\)\.GetResult\(\)|block\(\)" .
# Go: ignored errors
grep -rEn "_,? ?_ = |_ = [a-z]+\(" .
# String-built SQL (any)
grep -rEn "(SELECT|INSERT|UPDATE|DELETE).*(\+|\$\{|%s.*%|f\").*(FROM|INTO|SET|WHERE)" .
```

---

## Anti-Patterns

- ❌ **Fighting the framework** — reinventing routing/DI/ORM the framework already provides.
- ❌ **Non-idiomatic code** — writing Java-in-Go or Python-in-Rust; the next dev can't maintain it.
- ❌ **Blocking the event loop** (Node/Py-async/.NET/Rust) with sync CPU/IO.
- ❌ **Exposing ORM models directly** as API payloads (mass assignment / over-exposure).
- ❌ **Ignoring errors** — swallowed exceptions, unchecked Go `err`, unhandled promise rejections.
- ❌ **Sync heavy work in request** (Rails/Laravel) instead of a background job.
- ❌ **Dependency sprawl** — a new library for every trivial task; audit and prune.
- ❌ **Résumé-/hype-driven selection** — choosing a stack for novelty or benchmarks over team
  expertise and requirements; the team's fluency usually matters more than raw framework speed.
- ❌ **Rewriting an existing stack to your preference** — introducing a second framework/ORM or
  reformatting to a new style in a brownfield codebase instead of matching what's there.
- ❌ **Using APIs newer than the project pins** — breaking the build by ignoring the declared
  framework/runtime version.
- ❌ **Assuming the language is the bottleneck** — optimizing framework choice while the real cost
  is the database, N+1 queries, or the network.
