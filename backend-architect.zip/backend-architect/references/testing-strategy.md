# Testing Strategy (PROVE)

Tests are how you prove the backend is correct and keep it correct as it changes. This reference
covers the test pyramid, what to test at each level, contract testing for service boundaries, load
testing against the NFR budget, and how to test the hard parts (databases, async, messaging).

> **Rule**: Test behavior, not implementation. A good suite lets you refactor freely and catches
> regressions before users do. Fast feedback beats exhaustive-but-slow.

---

## The Test Pyramid

```
        ▲  fewer, slower, higher-confidence
       /e2e\        End-to-end: full system through real entry points (few)
      /------\
     /integration\  Integration: module + real DB/broker/HTTP (some)
    /------------\
   /    unit      \ Unit: pure logic, no IO, milliseconds (many)
  ────────────────
        ▼  more, faster, cheaper
```

| Level | Scope | Speed | Use for |
|-------|-------|-------|---------|
| **Unit** | One function/class, no IO | ms | Domain logic, calculations, edge cases, branch coverage |
| **Integration** | Component + real dependency (DB, cache, broker) | 10s–100s ms | Repositories, API endpoints, migrations, queries |
| **Contract** | Provider/consumer agreement | fast | Service & API boundaries |
| **E2E** | Whole system, real deployment-like | slow | A few critical user journeys only |
| **Load/Perf** | System under target traffic | slow | Validate NFR budget (p95/p99, throughput) |

**Anti-pattern — the ice-cream cone** (many slow e2e tests, few unit tests): slow, flaky, expensive.
Keep the base wide.

---

## Unit Tests — The Foundation

- Test the **domain layer** in isolation: pure functions, entities, value objects, domain services.
  This is why LLD keeps the domain framework/IO-free — it's trivially unit-testable.
- Cover **edge cases**: empty/null, boundaries (0, max, off-by-one), negative, unicode, huge input,
  and every branch of business rules.
- Use **test doubles** for collaborators:
  | Double | Purpose |
  |--------|---------|
  | Stub | Returns canned data |
  | Mock | Asserts an interaction happened |
  | Fake | Working lightweight impl (in-memory repo) |
  | Spy | Records calls for later assertions |
- Mock at architectural **boundaries** (repository/gateway interfaces), not internal details — over-
  mocking couples tests to implementation and makes refactoring painful.

---

## Integration Tests — Test the Seams

Where most real bugs hide: the boundaries between your code and the DB, cache, broker, and HTTP.
- Use **real dependencies in containers** via **Testcontainers** (spin up real Postgres/Redis/Kafka
  for the test), not mocks — mocks of a database don't catch SQL/mapping/migration bugs.
- Test repositories against a real DB (queries, transactions, constraints, migrations apply cleanly).
- Test API endpoints through the HTTP layer (routing, validation, authz, serialization, status codes).
- **Assert query counts** to catch N+1 regressions. → [scaling-and-performance.md](./scaling-and-performance.md)
- Reset state between tests (transaction rollback per test, or truncate/recreate) for isolation.

---

## Contract Testing — Safe Service Boundaries

In distributed systems, a provider changing its API can silently break consumers.
- **Consumer-driven contracts** (Pact): the consumer defines what it expects; the provider verifies
  it still satisfies every consumer's contract in CI. Breakage is caught before deploy, without
  slow full-stack e2e.
- Apply to REST/gRPC/GraphQL boundaries and to **event schemas** (a producer changing an event shape
  breaks consumers) — validate against a schema registry.

---

## Testing the Hard Parts

| Thing | How to test |
|-------|-------------|
| **Async / background jobs** | Trigger, then await the effect (poll with timeout); avoid `sleep`; test idempotency by running twice |
| **Messaging / consumers** | Publish a test event to a real/containerized broker; assert the consumer's effect; test duplicate & out-of-order delivery |
| **Time-dependent logic** | Inject a clock (don't call `now()` directly); freeze/advance time in tests |
| **Randomness** | Inject the RNG/seed |
| **External APIs** | Contract tests + a stub/mock server (WireMock/nock/respx); don't hit real third parties in CI |
| **Concurrency / races** | Run parallel operations and assert invariants; use race detectors (`go test -race`, thread sanitizers) |
| **Migrations** | Apply on a real DB in CI; test on production-scale data volume |

---

## Load & Performance Testing

Validate the NFRs from [requirements-and-estimation.md](./requirements-and-estimation.md).
- **Types**: **load** (expected peak), **stress** (find the breaking point), **soak** (sustained,
  reveals leaks), **spike** (sudden surge).
- **Tools**: k6, Locust, Gatling, JMeter, Artillery.
- Measure **percentiles (p95/p99)**, throughput, and error rate against the budget — not averages.
- Test in a production-like environment with realistic data volume; a query fast on 1k rows can be
  fatal on 100M.
- Watch saturation (CPU, memory, DB connections, queue depth) to find the true bottleneck.

---

## What to Test First (prioritize by risk)

1. **Critical paths**: money, auth, data integrity — highest consequence of failure.
2. **Complex business logic**: many branches/edge cases.
3. **Bug fixes**: every fix gets a **regression test** that fails before and passes after.
   → [bug-detection-and-fixing.md](./bug-detection-and-fixing.md)
4. **Boundaries**: input validation, authz checks, serialization.

Coverage is a guide, not a goal: aim high on critical paths; don't chase 100% by testing trivial
getters. Branch coverage on business logic matters more than line coverage overall.

---

## Test Quality & CI

- **Fast**: the unit suite runs in seconds; developers run it constantly. Parallelize integration tests.
- **Deterministic**: no flakiness. Flaky tests erode trust — fix or quarantine immediately. Common
  causes: real time/sleep, shared state, ordering assumptions, real network.
- **Isolated**: each test sets up and tears down its own state; no cross-test dependencies.
- **Readable**: **Arrange-Act-Assert**; one behavior per test; descriptive names
  (`rejects_transfer_when_balance_insufficient`).
- **In CI as a gate**: tests + coverage + security scan block merges. → [production-readiness.md](./production-readiness.md)
- **TDD** where it helps (complex logic): red → green → refactor tightens the design.

---

## Anti-Patterns

- ❌ **Ice-cream cone** — mostly slow e2e tests, few unit tests.
- ❌ **Mocking the database** — mocks don't catch SQL/mapping/migration bugs; use Testcontainers.
- ❌ **Over-mocking internals** — tests break on every refactor though behavior is unchanged.
- ❌ **`sleep()` in async tests** — flaky and slow; poll for the condition with a timeout.
- ❌ **Testing implementation details** — asserting private calls instead of observable behavior.
- ❌ **Hitting real third-party APIs in CI** — slow, flaky, rate-limited; stub them.
- ❌ **No regression test for a fixed bug** — it silently comes back.
- ❌ **Coverage as the only metric** — 100% coverage with no assertions proves nothing.
- ❌ **Ignoring/retrying flaky tests forever** — they hide real bugs and destroy trust in the suite.
